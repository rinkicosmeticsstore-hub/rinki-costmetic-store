# Rinki Cosmetics Store

Complete e-commerce website for **Rinki Cosmetics Store / Rinki Beauty Parlour** — Jangipur, Ghazipur, Uttar Pradesh.

Customers browse the catalogue and order on WhatsApp (no online payment, no cash-on-delivery prepayment). The shop owner manages products and photos from a private admin dashboard at `/admin`, and every change appears on the shop immediately.

Everything runs on **one Cloudflare Worker**: it serves the static storefront, the JSON API, uploaded product photos, and the admin dashboard. Product data lives in **Cloudflare D1** (SQLite), uploaded photos in **Cloudflare R2**, and no other service or secret key is needed.

---

## 1. What's inside

| Area | Pages / files | What it does |
| --- | --- | --- |
| Home | `public/index.html` + `assets/js/home.js` | Hero slider whose three image cards are pulled live from the catalogue, 8 category tiles, new arrivals, offers, WhatsApp CTAs |
| Shop | `public/shop.html` + `assets/js/shop.js` | Multi-select category chips with ✕ / Clear all, price filter, sorting, discount badges, Add to Cart, View |
| Product | `public/product.html` + `assets/js/product.js` | Photo gallery, price + discount, details, stock state, quantity, Add to Cart, Order on WhatsApp |
| Cart | `public/cart.html` + `assets/js/cart.js` | Quantities, totals, savings, WhatsApp order message builder (saved in the browser) |
| Contact | `public/contact.html` + `assets/js/contact.js` | Address, phone, opening hours, Google Map, WhatsApp |
| Admin | `worker/admin.html` + `public/assets/js/admin.js` | Login/setup, stats, product list with search + category filter, create/edit/delete, up to 6 photos per product, stock + availability, change password |
| API | `worker/index.js` | Public catalogue API, `/media/*` photos from R2, auth, protected admin API, security headers, origin checks |
| Seed data | `worker/seed.js`, `public/assets/js/data.js` | 40 starter products in 8 categories, used both for the database seed and as an offline fallback |
| Artwork | `public/assets/` | 40 product SVGs, 8 category tiles, 3 hero SVGs, no external image dependencies |
| Tools | `tools/build-seed.mjs`, `tools/make-art.py` | Regenerate the DB seed from `data.js`, regenerate all product/category artwork |

**Categories:** Makeup, Skincare, Haircare, Accessories, Fashion, Gift Items, Cosmetics, and **Offer Zone · ₹99 Store**.

---

## 2. Tech stack

- **Runtime:** Cloudflare Workers (ES modules, no framework, no build step)
- **Database:** Cloudflare D1 (SQLite) — schema in `schema.sql`, auto-created by the Worker
- **File storage:** Cloudflare R2 for admin-uploaded product photos (`/media/<key>`)
- **Frontend:** plain HTML + CSS + JavaScript (ES modules). No bundler, no npm runtime dependencies.
- **Auth:** one admin account, PBKDF2-SHA256 (100,000 iterations), HttpOnly + SameSite=Strict session cookie, login throttling, origin check on mutations
- **Dev tool:** Wrangler 4 (the only dependency)

---

## 3. Requirements

- Node.js **18 or newer** (20+ recommended) and npm
- A free Cloudflare account (only needed to publish; local development works offline)
- Nothing else — no database server, no PHP, no external accounts

---

## 4. Run it locally

```bash
# 1. install the one dev dependency (Wrangler)
npm install

# 2. start the site + API on http://localhost:3000
npm run dev
```

Open **http://localhost:3000**. Wrangler creates a local D1 database and R2 bucket under `.wrangler/` the first time, applies the schema, and inserts the 40 starter products automatically on the first request.

Useful URLs while developing:

- Storefront — http://localhost:3000
- Shop — http://localhost:3000/shop.html (or `/shop` when hosted)
- Admin — http://localhost:3000/admin
- Health check — http://localhost:3000/api/health → `{"ok":true,"products":40}`
- Catalogue API — http://localhost:3000/api/products

### Create the admin login (first run only)

1. Open http://localhost:3000/admin
2. On a brand-new database the page asks you to **create the administrator** — pick a username and a password of at least 8 characters.
3. After that, `/admin` always shows the normal login screen. There is exactly one admin account by design; you can change its password from the dashboard.

Forgot the local password? Reset the local database and start over:

```bash
npx wrangler d1 execute rinki-catalogue --local --command "DELETE FROM admins; DELETE FROM sessions;"
```

### Other scripts

```bash
npm run seed     # rebuild worker/seed.js from public/assets/js/data.js
npm run check    # syntax-check the Worker and admin scripts
```

To regenerate all product, category and hero artwork (Python 3 + no extra packages):

```bash
cd public && python3 ../tools/make-art.py
```

---

## 5. Deploy to Cloudflare (live website)

The site is a Worker with static assets, so deployment is three commands plus one edit.

```bash
# 1. log in to your Cloudflare account
npx wrangler login

# 2. create the database and copy the printed database_id
npx wrangler d1 create rinki-catalogue

# 3. create the image bucket
npx wrangler r2 bucket create rinki-product-images

# 4. paste the database_id from step 2 into wrangler.toml
#    (replace 00000000-0000-0000-0000-000000000000)

# 5. publish
npx wrangler deploy
```

Wrangler prints your live URL (something like `https://rinki-cosmetics-store.<your-subdomain>.workers.dev`).

Then:

1. Open `https://<your-url>/api/health` — it should report `{"ok":true,"products":40}`. The Worker builds the tables and loads the starter catalogue on this first request.
2. Open `https://<your-url>/admin` and create the real admin username and password. **This is the only account that can manage the shop — keep it safe.**
3. (Optional) Add a custom domain in the Cloudflare dashboard under **Workers & Pages → your Worker → Settings → Domains & Routes**.

### Deploying a later change

```bash
npx wrangler deploy
```

The database is untouched: existing products, photos and the admin account stay exactly as they are. New starter products are only ever added with `INSERT OR IGNORE`, so nothing you edited is overwritten.

### If you use a helper platform instead

`deploy-manifest.json` describes the same deployment (entry point, the three modules, and the `public/` assets folder) for platforms that deploy prebuilt Workers from a manifest. It contains no credentials.

---

## 6. Environment variables and secrets

**None are required.** This is deliberate: the Worker receives its database and bucket through the bindings in `wrangler.toml` (`DB`, `FILES`, plus `ASSETS` for static files), so there is no API key to leak.

`.env.example` documents the optional values:

- `CLOUDFLARE_API_TOKEN` / `CLOUDFLARE_ACCOUNT_ID` — only if you deploy with a token instead of `wrangler login`
- `WHATSAPP_NUMBER` — informational; the live number is set in `public/assets/js/data.js`
- `WRANGLER_SEND_METRICS=false` — silence Wrangler's telemetry prompt

Admin credentials are never stored in a file. The password is salted and hashed with PBKDF2-SHA256 inside D1. `.gitignore` already excludes `.env`, `.dev.vars`, `node_modules/` and `.wrangler/`.

---

## 7. Project structure

```
.
├── public/                     # everything the browser downloads
│   ├── index.html              # home
│   ├── shop.html               # shop / all products
│   ├── product.html            # single product
│   ├── cart.html               # cart + WhatsApp order
│   ├── contact.html            # contact + map
│   └── assets/
│       ├── css/style.css       # full design system (pink / white / purple)
│       ├── js/
│       │   ├── core.js         # header, footer, helpers, WhatsApp links, catalogue loading
│       │   ├── data.js         # STORE details, CATEGORIES, 40 SAMPLE_PRODUCTS
│       │   ├── home.js         # hero collage, category tiles, featured rows
│       │   ├── shop.js         # chips, filters, sorting, grid
│       │   ├── product.js      # product detail page
│       │   ├── cart.js         # cart page
│       │   ├── contact.js      # contact page
│       │   └── admin.js        # admin dashboard logic
│       ├── products/           # 40 product illustrations (SVG)
│       ├── categories/         # 8 category tiles (SVG)
│       └── hero/               # hero artwork (SVG)
├── worker/
│   ├── index.js                # the whole backend: API, auth, uploads, assets
│   ├── seed.js                 # generated starter catalogue (40 products)
│   └── admin.html              # admin dashboard markup, served at /admin
├── tools/
│   ├── build-seed.mjs          # data.js → seed.js
│   └── make-art.py             # regenerates every SVG
├── schema.sql                  # reference copy of the D1 schema
├── wrangler.toml               # Worker name, assets, D1 + R2 bindings
├── deploy-manifest.json        # manifest for manifest-based hosts
├── .env.example                # documented, empty optional variables
├── package.json                # scripts + Wrangler dev dependency
├── package-lock.json           # exact dependency versions
├── .gitignore
└── README.md
```

---

## 8. API reference

All responses are JSON. Mutations must come from the same origin (cross-site requests are rejected with 403).

| Method | Path | Auth | Purpose |
| --- | --- | --- | --- |
| GET | `/api/health` | – | `{ ok, products }` — also triggers schema + seed on a fresh DB |
| GET | `/api/products` | – | Visible products: `{ products, count, updatedAt }` |
| GET | `/media/<key>` | – | Product photo from R2 (immutable cache headers) |
| GET | `/api/auth/session` | – | `{ setupRequired, admin }` for the dashboard |
| POST | `/api/auth/setup` | – | Creates the single admin, only while none exists |
| POST | `/api/auth/login` | – | `{ username, password }` → session cookie |
| POST | `/api/auth/logout` | – | Clears the session |
| POST | `/api/auth/password` | admin | Change password (current + new) |
| GET | `/api/admin/stats` | admin | Counts for the dashboard |
| GET | `/api/admin/products` | admin | All products including hidden ones |
| POST | `/api/admin/products` | admin | Create or update a product (send `id` to update) |
| DELETE | `/api/admin/products?id=…` | admin | Delete a product and its uploaded photos |
| POST | `/api/admin/uploads` | admin | Multipart photo upload (jpg/png/gif/webp, max 4 MB each) → `/media/…` URLs |

Security notes: catalogue reads are public by design; every write requires a valid session; uploaded files are checked by magic bytes, not file extension; login attempts are throttled per IP (10 failures / 15 minutes); HTML responses carry `nosniff`, `referrer-policy` and a restrictive `permissions-policy`, and the dashboard is `noindex`.

---

## 9. Day-to-day shop management

1. Go to `/admin` and log in.
2. **Add a product:** name, category, selling price, MRP, description, details (one per line), stock, availability, then upload up to 6 photos. Without a photo the product falls back to a matching illustration.
3. **Edit:** click any product in the list, change what you need, save. Edits are live on the shop immediately.
4. **Hide instead of delete:** set availability to off to take a product out of the shop while keeping its photos and data.
5. **Offers:** put a product in the **Offer Zone · ₹99 Store** category to show it in the ₹99 section.

---

## 10. Notes and limits

- The cart is stored in the browser (localStorage). Orders are placed on WhatsApp, so there is no order table and no payment integration — that is intentional for this shop.
- There is a single admin account; the setup endpoint refuses to run once one exists.
- PBKDF2 is capped at 100,000 iterations on Cloudflare Workers, which is why that value is fixed.
- `.html` URLs redirect to clean URLs (`/shop.html` → `/shop`) on the hosted platform; both forms work locally.
- `worker/seed.js` is generated — edit `public/assets/js/data.js` and run `npm run seed` instead of editing it by hand.

---

© Rinki Cosmetics Store, Jangipur, Ghazipur (Uttar Pradesh). WhatsApp: 9696875106.
