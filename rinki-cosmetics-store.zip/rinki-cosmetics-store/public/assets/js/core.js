/* Rinki Cosmetics Store - shared storefront logic */

const LS_PRODUCTS = "rinki_products_v1";
const LS_CART = "rinki_cart_v1";
const LS_ADMIN = "rinki_admin_v1";

/* ---------- helpers ---------- */
function money(n) {
  return STORE.currency + Number(n || 0).toLocaleString("en-IN");
}
function esc(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function byId(id) { return document.getElementById(id); }
function categoryName(id) {
  const c = CATEGORIES.find(c => c.id === id);
  return c ? c.name : "All Products";
}

/* ---------- catalogue (live from the shop database) ---------- */
const LS_PRODUCTS_CACHE = "rinki_products_cache_v2";
let catalogue = null;
let cataloguePromise = null;

function normaliseProduct(p) {
  const images = Array.isArray(p.images) && p.images.length ? p.images.slice() : (p.image ? [p.image] : []);
  return {
    id: String(p.id || ""),
    name: String(p.name || "Product"),
    category: p.category || "makeup",
    price: Number(p.price) || 0,
    mrp: Number(p.mrp) || Number(p.price) || 0,
    rating: Number(p.rating) || 4.5,
    reviews: Number(p.reviews) || 0,
    tag: p.tag || "",
    desc: String(p.description || p.desc || ""),
    details: Array.isArray(p.details) ? p.details : [],
    images: images,
    image: images[0] || "assets/hero/hero-1.svg",
    stock: p.stock == null ? 12 : Math.max(0, Number(p.stock) || 0),
    available: p.available === undefined ? true : !!p.available
  };
}
function readProductCache() {
  try {
    const saved = JSON.parse(localStorage.getItem(LS_PRODUCTS_CACHE) || "null");
    if (Array.isArray(saved) && saved.length) return saved.map(normaliseProduct);
  } catch (e) { /* ignore corrupt cache */ }
  return null;
}
function writeProductCache(list) {
  try {
    localStorage.setItem(LS_PRODUCTS_CACHE, JSON.stringify(list));
    localStorage.setItem(LS_PRODUCTS_CACHE + "_at", String(Date.now()));
  } catch (e) { /* storage may be full or blocked */ }
}
function getProducts() {
  if (catalogue) return catalogue;
  const cached = readProductCache();
  if (cached) return cached;
  return SAMPLE_PRODUCTS.map(normaliseProduct);
}
function loadCatalogue(force) {
  if (catalogue && !force) return Promise.resolve(catalogue);
  if (cataloguePromise) return cataloguePromise;
  cataloguePromise = (async () => {
    try {
      const res = await fetch("/api/products", { headers: { Accept: "application/json" }, cache: "no-store" });
      if (!res.ok) throw new Error("HTTP " + res.status);
      const data = await res.json();
      catalogue = (data.products || []).map(normaliseProduct);
      writeProductCache(catalogue);
    } catch (err) {
      const cached = readProductCache();
      catalogue = cached || SAMPLE_PRODUCTS.map(normaliseProduct);
    } finally {
      cataloguePromise = null;
    }
    sysncCartWithCatalogue();
    return catalogue;
  })();
  return cataloguePromise;
}
function getProduct(id) {
  return getProducts().find(p => p.id === id) || null;
}
function sysncCartWithCatalogue() {
  const products = getProducts();
  const ids = new Set(products.map(p => p.id));
  const cart = getCart()
    .filter(line => ids.has(line.id))
    .map(line => {
      const product = products.find(p => p.id === line.id);
      const max = Math.max(1, product.stock || 0);
      return { id: line.id, qty: Math.min(line.qty, max) };
    });
  localStorage.setItem(LS_CART, JSON.stringify(cart));
  updateCartBadge();
}

/* ---------- cart ---------- */
function getCart() {
  try { return JSON.parse(localStorage.getItem(LS_CART) || "[]") || []; }
  catch (e) { return []; }
}
function setCart(items) {
  localStorage.setItem(LS_CART, JSON.stringify(items));
  updateCartBadge();
}
function addToCart(id, qty, silent) {
  const product = getProduct(id);
  if (!product) return;
  if (product.stock <= 0) {
    toast("Sorry, " + product.name + " is out of stock");
    return;
  }
  qty = Math.max(1, Number(qty) || 1);
  const cart = getCart();
  const line = cart.find(i => i.id === id);
  const inCart = line ? line.qty : 0;
  const allowed = Math.max(1, product.stock);
  if (inCart + qty > allowed) {
    toast("Only " + allowed + " available in the shop");
  }
  const next = Math.min(allowed, inCart + qty);
  if (line) line.qty = next;
  else cart.push({ id: id, qty: next });
  setCart(cart);
  if (!silent) toast(product.name + " added to cart");
}
function updateQty(id, qty) {
  const cart = getCart();
  const line = cart.find(i => i.id === id);
  if (!line) return;
  const product = getProduct(id);
  const allowed = product ? Math.max(1, product.stock) : 99;
  line.qty = Math.min(allowed, Math.max(1, Number(qty) || 1));
  setCart(cart);
}
function removeFromCart(id) {
  setCart(getCart().filter(i => i.id !== id));
}
function cartCount() {
  return getCart().reduce((n, i) => n + i.qty, 0);
}
function cartLines() {
  const products = getProducts();
  return getCart().map(line => {
    const p = products.find(p => p.id === line.id);
    return p ? { product: p, qty: line.qty, total: p.price * line.qty } : null;
  }).filter(Boolean);
}
function cartSubtotal() {
  return cartLines().reduce((n, l) => n + l.total, 0);
}
function cartSavings() {
  return cartLines().reduce((n, l) => n + Math.max(0, (l.product.mrp - l.product.price)) * l.qty, 0);
}
function updateCartBadge() {
  const n = cartCount();
  document.querySelectorAll("[data-cart-count]").forEach(el => {
    el.textContent = n;
    el.classList.toggle("is-empty", n === 0);
  });
}

/* ---------- toast ---------- */
let toastTimer;
function toast(message) {
  let el = byId("toast");
  if (!el) {
    el = document.createElement("div");
    el.id = "toast";
    el.className = "toast";
    document.body.appendChild(el);
  }
  el.innerHTML = '<span class="toast__tick">✓</span><span>' + esc(message) + "</span>";
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
}

/* ---------- WhatsApp ---------- */
function waLink(text) {
  return "https://wa.me/" + STORE.whatsapp + "?text=" + encodeURIComponent(text);
}
function openWhatsApp(text) {
  window.open(waLink(text), "_blank", "noopener");
}

/* ---------- layout ---------- */
function renderHeader() {
  const q = new URLSearchParams(location.search).get("q") || "";
  const page = (location.pathname.split("/").pop() || "index.html").replace(".html", "") || "index";
  const nav = [
    { id: "index", label: "Home", href: "index.html" },
    { id: "shop", label: "Shop All", href: "shop.html" },
    { id: "new", label: "New Arrivals", href: "shop.html?tag=new" },
    { id: "trending", label: "Trending", href: "shop.html?tag=trending" },
    { id: "contact", label: "Contact", href: "contact.html" },
    { id: "admin", label: "Admin", href: "/admin" }
  ];
  const html = `
  <div class="topbar">
    <div class="container topbar__inner">
      <span class="topbar__item">✦ Free delivery on orders above ₹999 in Ghazipur</span>
      <span class="topbar__item topbar__item--right">Order on WhatsApp: <a href="https://wa.me/${STORE.whatsapp}" target="_blank" rel="noopener">${esc(STORE.phoneDisplay)}</a></span>
    </div>
  </div>
  <header class="header">
    <div class="container header__inner">
      <a class="brand" href="index.html" aria-label="${esc(STORE.name)} home">
        <span class="brand__mark">R</span>
        <span class="brand__text"><strong>Rinki</strong><small>Cosmetics Store</small></span>
      </a>

      <form class="search" role="search" onsubmit="event.preventDefault(); const v=this.q.value.trim(); location.href='shop.html'+(v?'?q='+encodeURIComponent(v):'');">
        <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>
        <input type="search" name="q" value="${esc(q)}" placeholder="Search lipstick, serum, hair oil…" aria-label="Search products">
        <button type="submit">Search</button>
      </form>

      <div class="header__actions">
        <a class="icon-btn" href="cart.html" aria-label="Open cart">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 7h12l-1 13H7L6 7z"/><path d="M9 7a3 3 0 016 0"/></svg>
          <span class="badge" data-cart-count>0</span>
        </a>
        <a class="btn btn--wa btn--sm header__wa" href="https://wa.me/${STORE.whatsapp}" target="_blank" rel="noopener">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 12a8 8 0 11-3.2-6.4L20 4l-1.4 3.2A7.9 7.9 0 0120 12z"/><path d="M8.5 14.5c1.6 1.6 4 2.6 5.5 2.6"/></svg>
          WhatsApp
        </a>
        <button class="menu-btn" type="button" aria-label="Open menu" aria-expanded="false" onclick="toggleMenu(this)">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>

    <nav class="nav" id="mainNav">
      <div class="container nav__inner">
        ${nav.map(n => `<a href="${n.href}" class="${page === n.id || (n.id === "shop" && page === "shop") ? "is-active" : ""}">${n.label}</a>`).join("")}
        ${CATEGORIES.map(c => `<a href="shop.html?category=${c.id}" class="nav__cat">${esc(c.name)}</a>`).join("")}
      </div>
    </nav>
  </header>`;
  const holder = byId("site-header");
  if (holder) holder.innerHTML = html;
  updateCartBadge();
}
function toggleMenu(btn) {
  const nav = byId("mainNav");
  if (!nav) return;
  const open = nav.classList.toggle("is-open");
  btn.setAttribute("aria-expanded", open ? "true" : "false");
}

function renderFooter() {
  const holder = byId("site-footer");
  if (!holder) return;
  holder.innerHTML = `
  <footer class="footer">
    <div class="container footer__grid">
      <div class="footer__col footer__brand">
        <a class="brand brand--light" href="index.html">
          <span class="brand__mark">R</span>
          <span class="brand__text"><strong>Rinki</strong><small>Cosmetics Store</small></span>
        </a>
        <p>Hand-picked makeup, skincare and haircare essentials at honest prices. Order directly on WhatsApp and get it delivered to your doorstep.</p>
        <a class="btn btn--wa btn--sm" href="https://wa.me/${STORE.whatsapp}" target="_blank" rel="noopener">Chat with us</a>
      </div>
      <div class="footer__col">
        <h4>Shop</h4>
        <a href="shop.html">All Products</a>
        <a href="shop.html?tag=new">New Arrivals</a>
        <a href="shop.html?tag=trending">Trending</a>
        <a href="shop.html?tag=bestseller">Bestsellers</a>
      </div>
      <div class="footer__col">
        <h4>Categories</h4>
        ${CATEGORIES.map(c => `<a href="shop.html?category=${c.id}">${esc(c.name)}</a>`).join("")}
      </div>
      <div class="footer__col">
        <h4>Store</h4>
        <p class="footer__line">${esc(STORE.address)}</p>
        <p class="footer__line"><a href="tel:+${STORE.whatsapp}">${esc(STORE.phoneDisplay)}</a></p>
        <p class="footer__line">${esc(STORE.hours)}</p>
        <a href="contact.html#location">Shop location &amp; directions</a>
        <a href="contact.html">Contact us</a>
        <a href="/admin">Admin dashboard</a>
      </div>
    </div>
    <div class="container footer__bottom">
      <p>© ${new Date().getFullYear()} ${esc(STORE.name)} · Jangipur, Ghazipur, Uttar Pradesh</p>
      <p>No online payment · No cash on delivery · Orders confirmed on WhatsApp</p>
    </div>
  </footer>`;
}

/* ---------- product cards ---------- */
function tagLabel(tag) {
  if (tag === "new") return "New";
  if (tag === "trending") return "Trending";
  if (tag === "bestseller") return "Bestseller";
  return "";
}
function stars(rating) {
  const full = Math.round(rating);
  return "★★★★★".slice(0, full) + "☆☆☆☆☆".slice(0, 5 - full);
}
function productCard(p) {
  const off = p.mrp > p.price ? Math.round(((p.mrp - p.price) / p.mrp) * 100) : 0;
  const out = p.stock <= 0;
  return `
  <article class="card${out ? " is-out" : ""}">
    <a class="card__media" href="product.html?id=${encodeURIComponent(p.id)}" aria-label="${esc(p.name)}">
      <img src="${esc(p.image)}" alt="${esc(p.name)}" loading="lazy">
      ${off ? `<span class="pill pill--off">${off}% off</span>` : ""}
      ${out ? `<span class="pill pill--out">Out of stock</span>` : p.tag ? `<span class="pill pill--tag pill--${esc(p.tag)}">${tagLabel(p.tag)}</span>` : ""}
    </a>
    <div class="card__body">
      <span class="card__cat">${esc(categoryName(p.category))}</span>
      <h3 class="card__title"><a href="product.html?id=${encodeURIComponent(p.id)}">${esc(p.name)}</a></h3>
      <div class="rating"><span class="rating__stars">${stars(p.rating)}</span> ${Number(p.rating).toFixed(1)} <span class="rating__count">(${p.reviews})</span></div>
      <div class="price"><strong>${money(p.price)}</strong>${p.mrp > p.price ? `<s>${money(p.mrp)}</s>` : ""}</div>
      <div class="card__actions">
        ${out
          ? `<button class="btn btn--ghost btn--block" type="button" disabled>Out of stock</button>`
          : `<button class="btn btn--primary btn--block" type="button" onclick="addToCart('${esc(p.id)}',1)">Add to cart</button>`}
        <a class="btn btn--ghost btn--block" href="product.html?id=${encodeURIComponent(p.id)}">View</a>
      </div>
    </div>
  </article>`;
}
function renderGrid(container, products, emptyMessage) {
  if (!container) return;
  if (!products.length) {
    container.innerHTML = `<div class="empty">
      <div class="empty__icon">✦</div>
      <h3>Nothing here yet</h3>
      <p>${esc(emptyMessage || "Try another category or search keyword.")}</p>
      <a class="btn btn--primary" href="shop.html">Browse all products</a>
    </div>`;
    return;
  }
  container.innerHTML = products.map(productCard).join("");
}

/* ---------- bootstrap ---------- */
document.addEventListener("DOMContentLoaded", () => {
  renderHeader();
  renderFooter();
  updateCartBadge();
});
