/* Product detail page */
document.addEventListener("DOMContentLoaded", async () => {
  await loadCatalogue();

  const id = new URLSearchParams(location.search).get("id");
  const p = id ? getProduct(id) : null;
  const host = byId("pdp");

  if (!p) {
    host.innerHTML = `<div class="empty" style="grid-column:1/-1">
      <div class="empty__icon">✦</div>
      <h3>Product not found</h3>
      <p>It may have been removed from the catalogue.</p>
      <a class="btn btn--primary" href="shop.html">Browse all products</a>
    </div>`;
    renderGrid(byId("relatedGrid"), getProducts().slice(0, 4));
    return;
  }

  document.title = p.name + " | Rinki Cosmetics Store";
  const off = p.mrp > p.price ? Math.round(((p.mrp - p.price) / p.mrp) * 100) : 0;
  const details = Array.isArray(p.details) ? p.details : [];
  const gallery = (p.images && p.images.length ? p.images : [p.image]).slice(0, 6);
  const outOfStock = p.stock <= 0;

  host.innerHTML = `
    <div class="pdp__media">
      <img id="pdpMain" src="${esc(gallery[0])}" alt="${esc(p.name)}">
      ${p.tag ? `<span class="pill pill--tag pill--${esc(p.tag)}">${tagLabel(p.tag)}</span>` : ""}
      ${off ? `<span class="pill pill--off" style="left:auto;right:12px;top:auto;bottom:12px">${off}% off</span>` : ""}
      ${gallery.length > 1 ? `<div class="pdp__thumbs">${gallery.map((src, i) => `
        <button type="button" class="pdp__thumb${i === 0 ? " is-active" : ""}" data-src="${esc(src)}" aria-label="Show photo ${i + 1}">
          <img src="${esc(src)}" alt="">
        </button>`).join("")}</div>` : ""}
    </div>
    <div>
      <div class="crumbs"><a href="index.html">Home</a> <span>/</span> <a href="shop.html?category=${esc(p.category)}">${esc(categoryName(p.category))}</a> <span>/</span> <span>${esc(p.name)}</span></div>
      <span class="card__cat">${esc(categoryName(p.category))}</span>
      <h1>${esc(p.name)}</h1>
      <div class="pdp__rating">
        <span class="rating__stars" style="font-size:14px">${stars(p.rating)}</span>
        <strong style="color:var(--ink)">${Number(p.rating).toFixed(1)}</strong>
        <span>· ${p.reviews} verified reviews</span>
      </div>
      <div class="pdp__price">
        <strong>${money(p.price)}</strong>
        ${p.mrp > p.price ? `<s>${money(p.mrp)}</s>` : ""}
        ${off ? `<span class="pdp__save">Save ${off}%</span>` : ""}
      </div>
      <p class="form__note">Inclusive of all taxes · Price confirmed on WhatsApp</p>
      ${outOfStock
        ? `<p class="pdp__stock pdp__stock--out">Currently out of stock — message us on WhatsApp and we will arrange it for you.</p>`
        : p.stock <= 5
          ? `<p class="pdp__stock pdp__stock--low">Hurry, only ${p.stock} left in the shop</p>`
          : `<p class="pdp__stock pdp__stock--ok">In stock — ready to deliver from Jangipur</p>`}
      <p class="pdp__desc">${esc(p.desc)}</p>
      ${details.length ? `<ul class="pdp__details">${details.map(d => `<li>${esc(d)}</li>`).join("")}</ul>` : ""}

      <div class="pdp__buy">
        <div class="qty">
          <button type="button" onclick="stepQty(-1)" aria-label="Decrease quantity">−</button>
          <input id="qtyInput" type="number" value="1" min="1" max="${Math.max(1, p.stock)}" aria-label="Quantity">
          <button type="button" onclick="stepQty(1)" aria-label="Increase quantity">+</button>
        </div>
        <button class="btn btn--primary btn--lg" type="button" onclick="addCurrent()" ${outOfStock ? "disabled" : ""}>
          ${outOfStock ? "Out of stock" : "Add to cart"}
        </button>
        <button class="btn btn--wa btn--lg" type="button" onclick="orderNow()">
          <svg viewBox="0 0 24 24"><path d="M20 12a8 8 0 11-3.2-6.4L20 4l-1.4 3.2A7.9 7.9 0 0120 12z"/></svg>
          Order on WhatsApp
        </button>
      </div>

      <div class="pdp__trust">
        <div><strong>Genuine product</strong>Sourced from authorised sellers</div>
        <div><strong>Local delivery</strong>Jangipur &amp; nearby Ghazipur</div>
        <div><strong>Easy help</strong>WhatsApp support 9 AM – 8 PM</div>
      </div>
    </div>`;

  host.querySelectorAll(".pdp__thumb").forEach(btn => {
    btn.addEventListener("click", () => {
      byId("pdpMain").src = btn.dataset.src;
      host.querySelectorAll(".pdp__thumb").forEach(b => b.classList.toggle("is-active", b === btn));
    });
  });

  function qty() {
    const v = parseInt(byId("qtyInput").value, 10);
    const max = Math.max(1, p.stock);
    return isNaN(v) || v < 1 ? 1 : Math.min(v, max);
  }
  window.stepQty = function (delta) {
    const input = byId("qtyInput");
    const max = Math.max(1, p.stock);
    const next = Math.min(max, Math.max(1, qty() + delta));
    input.value = next;
  };
  window.addCurrent = function () {
    if (outOfStock) {
      toast("This product is out of stock right now");
      return;
    }
    addToCart(p.id, qty());
  };
  window.orderNow = function () {
    const total = p.price * qty();
    openWhatsApp(
      "Hello Rinki Cosmetics Store! 👋\n\nI want to order:\n\n" +
      "• " + p.name + "\n  Quantity: " + qty() + "\n  Price: " + money(p.price) + " each\n  Item total: " + money(total) +
      (outOfStock ? "\n\n(Please let me know when it is back in stock)" : "") +
      "\n\nPlease confirm availability and delivery details.\n(No COD / no online payment as per store policy)"
    );
  };

  /* related products */
  const related = getProducts().filter(x => x.category === p.category && x.id !== p.id).slice(0, 4);
  renderGrid(byId("relatedGrid"), related.length ? related : getProducts().filter(x => x.id !== p.id).slice(0, 4));
});
