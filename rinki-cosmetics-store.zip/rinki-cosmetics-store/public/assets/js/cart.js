/* Cart page + WhatsApp checkout */
document.addEventListener("DOMContentLoaded", async () => {
  await loadCatalogue();
  const host = byId("cartWrap");
  const draft = { name: "", phone: "", address: "", city: "", pincode: "", note: "" };
  const DELIVERY = 49, FREE_ABOVE = 999;

  const deliveryFee = () => (cartSubtotal() >= FREE_ABOVE || cartSubtotal() === 0 ? 0 : DELIVERY);
  const grandTotal = () => cartSubtotal() + deliveryFee();

  function render() {
    const lines = cartLines();
    if (!lines.length) {
      host.innerHTML = `<div class="empty">
        <div class="empty__icon">🛍</div>
        <h3>Your cart is empty</h3>
        <p>Add a few beauty favourites and they will show up here.</p>
        <a class="btn btn--primary btn--lg" href="shop.html">Start shopping</a>
      </div>`;
      updateCartBadge();
      return;
    }

    host.innerHTML = `
      <div class="panel">
        <h2>${lines.reduce((n, l) => n + l.qty, 0)} item(s) in your cart <a class="section__link" href="shop.html">+ Add more</a></h2>
        ${lines.map(l => `
          <div class="line">
            <img class="line__img" src="${esc(l.product.image)}" alt="${esc(l.product.name)}">
            <div>
              <a class="line__name" href="product.html?id=${encodeURIComponent(l.product.id)}">${esc(l.product.name)}</a>
              <p class="line__meta">${esc(categoryName(l.product.category))} · ${money(l.product.price)} each</p>
              <div class="line__controls">
                <div class="qty qty--sm">
                  <button type="button" onclick="changeQty('${esc(l.product.id)}',-1)" aria-label="Decrease quantity">−</button>
                  <input type="number" value="${l.qty}" min="1" max="99" aria-label="Quantity for ${esc(l.product.name)}"
                    onchange="setQty('${esc(l.product.id)}',this.value)">
                  <button type="button" onclick="changeQty('${esc(l.product.id)}',1)" aria-label="Increase quantity">+</button>
                </div>
                <button class="link-danger" type="button" onclick="dropItem('${esc(l.product.id)}')">Remove</button>
              </div>
            </div>
            <div class="line__price">${money(l.total)}${l.product.mrp > l.product.price ? `<small>${money(l.product.mrp * l.qty)}</small>` : ""}</div>
          </div>`).join("")}
        <div style="display:flex;justify-content:space-between;gap:12px;margin-top:18px;flex-wrap:wrap">
          <a class="btn btn--ghost btn--sm" href="shop.html">← Continue shopping</a>
          <a class="btn btn--wa btn--sm" href="https://wa.me/${STORE.whatsapp}?text=${encodeURIComponent("Hi Rinki Cosmetics, I need help with my order.")}" target="_blank" rel="noopener">Ask a question</a>
        </div>
      </div>

      <div>
        <div class="panel summary">
          <h2>Order summary</h2>
          <dl>
            <div><dt>Subtotal (${cartCount()} items)</dt><dd>${money(cartSubtotal())}</dd></div>
            ${cartSavings() > 0 ? `<div><dt>You save</dt><dd style="color:var(--green);font-weight:600">− ${money(cartSavings())}</dd></div>` : ""}
            <div><dt>Delivery</dt><dd>${deliveryFee() ? money(deliveryFee()) : (cartSubtotal() >= FREE_ABOVE ? "Free" : "—")}</dd></div>
            <div class="total"><dt>Total payable</dt><dd>${money(grandTotal())}</dd></div>
          </dl>
          ${cartSubtotal() < FREE_ABOVE ? `<div class="savings">Add ${money(FREE_ABOVE - cartSubtotal())} more to get free delivery.</div>` : `<div class="savings">✦ You have unlocked free local delivery.</div>`}
          <p class="notice">No online payment · No cash on delivery. Payment is arranged directly with the store on WhatsApp.</p>
        </div>

        <div class="panel" style="margin-top:18px">
          <h2>Delivery details</h2>
          <form class="form" id="checkoutForm" novalidate>
            <div class="form__row">
              <div class="field">
                <label for="cName">Full name *</label>
                <input id="cName" data-field="name" type="text" placeholder="Your name" value="${esc(draft.name)}" autocomplete="name">
              </div>
              <div class="field">
                <label for="cPhone">WhatsApp number *</label>
                <input id="cPhone" data-field="phone" type="tel" inputmode="numeric" placeholder="10-digit mobile" value="${esc(draft.phone)}" autocomplete="tel">
              </div>
            </div>
            <div class="field">
              <label for="cAddress">Full address *</label>
              <textarea id="cAddress" data-field="address" placeholder="House / street / landmark" autocomplete="street-address">${esc(draft.address)}</textarea>
            </div>
            <div class="form__row">
              <div class="field">
                <label for="cCity">City / village *</label>
                <input id="cCity" data-field="city" type="text" placeholder="e.g. Jangipur" value="${esc(draft.city)}" autocomplete="address-level2">
              </div>
              <div class="field">
                <label for="cPin">PIN code</label>
                <input id="cPin" data-field="pincode" type="text" inputmode="numeric" placeholder="233305" value="${esc(draft.pincode)}" autocomplete="postal-code">
              </div>
            </div>
            <div class="field">
              <label for="cNote">Order note (optional)</label>
              <input id="cNote" data-field="note" type="text" placeholder="Preferred delivery time, shade preference…" value="${esc(draft.note)}">
            </div>
            <button class="btn btn--wa btn--lg btn--block" type="submit">
              <svg viewBox="0 0 24 24"><path d="M20 12a8 8 0 11-3.2-6.4L20 4l-1.4 3.2A7.9 7.9 0 0120 12z"/><path d="M8.5 14.5c1.6 1.6 4 2.6 5.5 2.6"/></svg>
              Place order on WhatsApp
            </button>
            <p class="form__note">Tapping this opens WhatsApp with your full order written out. Just press send — we reply to confirm.</p>
          </form>
        </div>
      </div>`;

    updateCartBadge();
  }

  /* keep typed delivery details alive across re-renders */
  host.addEventListener("input", e => {
    const field = e.target.dataset && e.target.dataset.field;
    if (field) {
      draft[field] = e.target.value;
      e.target.classList.remove("err");
    }
  });

  /* quantity actions (re-render, draft keeps form values) */
  window.changeQty = function (id, delta) {
    const line = getCart().find(i => i.id === id);
    if (!line) return;
    updateQty(id, line.qty + delta);
    render();
  };
  window.setQty = function (id, value) {
    updateQty(id, value);
    render();
  };
  window.dropItem = function (id) {
    removeFromCart(id);
    render();
    toast("Item removed from cart");
  };

  /* checkout */
  function buildMessage() {
    const lines = cartLines();
    const rows = lines.map((l, i) =>
      (i + 1) + ". " + l.product.name +
      "\n   Qty: " + l.qty + " × " + money(l.product.price) + " = " + money(l.total)
    ).join("\n");
    return [
      "🛍️ *NEW ORDER — Rinki Cosmetics Store*",
      "",
      "*Customer details*",
      "👤 Name: " + draft.name,
      "📞 WhatsApp: " + draft.phone,
      "📍 Address: " + draft.address,
      "🏙️ City: " + draft.city + (draft.pincode ? " - " + draft.pincode : ""),
      draft.note ? "📝 Note: " + draft.note : null,
      "",
      "*Order items*",
      rows,
      "",
      "Subtotal: " + money(cartSubtotal()),
      "Delivery: " + (deliveryFee() ? money(deliveryFee()) : "Free"),
      "*Total: " + money(grandTotal()) + "*",
      "",
      "Payment: to be arranged with the store (no online payment / no COD).",
      "Please confirm my order. Thank you! 🙏"
    ].filter(x => x !== null).join("\n");
  }

  host.addEventListener("submit", e => {
    if (e.target.id !== "checkoutForm") return;
    e.preventDefault();
    const required = [
      { id: "cName", key: "name", test: v => v.trim().length >= 2 },
      { id: "cPhone", key: "phone", test: v => /^[6-9]\d{9}$/.test(v.replace(/\D/g, "")) },
      { id: "cAddress", key: "address", test: v => v.trim().length >= 5 },
      { id: "cCity", key: "city", test: v => v.trim().length >= 2 }
    ];
    let ok = true, firstBad = null;
    required.forEach(r => {
      const el = byId(r.id);
      const valid = r.test(el.value || "");
      el.classList.toggle("err", !valid);
      if (!valid) { ok = false; if (!firstBad) firstBad = el; }
    });
    if (!ok) {
      toast("Please fill your name, WhatsApp number, address and city");
      if (firstBad) { firstBad.focus(); firstBad.scrollIntoView({ behavior: "smooth", block: "center" }); }
      return;
    }
    openWhatsApp(buildMessage());
    toast("Order ready in WhatsApp — press send to confirm");
  });

  render();
});
