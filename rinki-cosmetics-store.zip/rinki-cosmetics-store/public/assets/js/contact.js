/* Contact form → WhatsApp message */
document.addEventListener("DOMContentLoaded", () => {
  const form = byId("contactForm");
  if (!form) return;

  form.addEventListener("submit", e => {
    e.preventDefault();
    const name = byId("cName").value.trim();
    const phone = byId("cPhone").value.replace(/\D/g, "");
    const topic = byId("cTopic").value;
    const message = byId("cMessage").value.trim();

    let ok = true;
    [["cName", name.length >= 2], ["cPhone", /^[6-9]\d{9}$/.test(phone)], ["cMessage", message.length >= 3]].forEach(([id, valid]) => {
      byId(id).classList.toggle("err", !valid);
      if (!valid) ok = false;
    });
    if (!ok) {
      toast("Please add your name, a valid 10-digit number and a message");
      return;
    }

    const text = "Hello Rinki Cosmetics Store! 👋\n\n" +
      "👤 Name: " + name + "\n" +
      "📞 Phone: " + phone + "\n" +
      "📌 Subject: " + topic + "\n\n" +
      "💬 Message:\n" + message;
    openWhatsApp(text);
    toast("Opening WhatsApp with your message");
    form.reset();
  });
});
