/* Shop / catalogue page: search, category chips, price filter & sorting */
document.addEventListener("DOMContentLoaded", async () => {
  await loadCatalogue();
  const params = new URLSearchParams(location.search);
  const state = {
    q: (params.get("q") || "").trim(),
    categories: (params.get("category") || "")
      .split(",")
      .map(id => id.trim())
      .filter(id => CATEGORIES.some(c => c.id === id)),
    tag: params.get("tag") || "",
    price: params.get("price") || "",
    sort: params.get("sort") || "featured"
  };
  const all = getProducts();

  /* heading */
  function updateHeading() {
    const heading = state.categories.length === 1
      ? categoryName(state.categories[0])
      : state.tag === "new" ? "New Arrivals"
      : state.tag === "trending" ? "Trending Products"
      : state.tag === "bestseller" ? "Bestsellers"
      : state.q ? 'Results for "' + state.q + '"'
      : "All Products";
    byId("pageTitle").textContent = heading;
    byId("crumbNow").textContent = heading;
    byId("pageSub").textContent = state.categories.length === 1
      ? "Explore our " + categoryName(state.categories[0]).toLowerCase() + " collection."
      : "Makeup, skincare, haircare, fashion, gift items and beauty accessories.";
  }

  /* keep the address bar shareable */
  function syncUrl() {
    const p = new URLSearchParams();
    if (state.q) p.set("q", state.q);
    if (state.categories.length) p.set("category", state.categories.join(","));
    if (state.tag) p.set("tag", state.tag);
    if (state.price) p.set("price", state.price);
    if (state.sort && state.sort !== "featured") p.set("sort", state.sort);
    history.replaceState({}, "", "shop.html" + (p.toString() ? "?" + p : ""));
  }

  /* category chips (top filter bar) */
  function renderCategories() {
    const host = byId("categoryChips");
    host.innerHTML = CATEGORIES.map(c => {
      const on = state.categories.includes(c.id);
      return `<button type="button" class="chip${on ? " chip--active" : ""}" data-cat="${c.id}" aria-pressed="${on}">${esc(c.name)}${on ? ' <span class="chip__x" aria-hidden="true">✕</span>' : ""}</button>`;
    }).join("") + (state.categories.length ? '<a class="chip chip--clear" href="shop.html">Clear all</a>' : "");
    host.querySelectorAll("[data-cat]").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = btn.dataset.cat;
        const i = state.categories.indexOf(id);
        if (i >= 0) state.categories.splice(i, 1);
        else state.categories.push(id);
        syncUrl();
        renderCategories();
        updateHeading();
        chips();
        apply();
      });
    });
  }

  /* price filters */
  document.querySelectorAll("#priceFilters a").forEach(a => {
    if (state.price === a.dataset.price) a.classList.add("is-active");
    a.addEventListener("click", e => {
      e.preventDefault();
      state.price = state.price === a.dataset.price ? "" : a.dataset.price;
      document.querySelectorAll("#priceFilters a").forEach(x => x.classList.remove("is-active"));
      if (state.price) a.classList.add("is-active");
      syncUrl(); chips(); apply();
    });
  });

  /* sort */
  const sortSelect = byId("sortSelect");
  sortSelect.value = state.sort;
  sortSelect.addEventListener("change", () => { state.sort = sortSelect.value; syncUrl(); apply(); });

  /* active chips for search / tag / price */
  function chips() {
    const list = [];
    if (state.q) list.push({ label: 'Search: "' + state.q + '"', clear: "q" });
    if (state.tag) list.push({ label: tagLabel(state.tag), clear: "tag" });
    if (state.price) {
      const map = { "under-200": "Under ₹200", "200-400": "₹200 – ₹400", "400-600": "₹400 – ₹600", "above-600": "Above ₹600" };
      list.push({ label: map[state.price], clear: "price" });
    }
    const host = byId("activeChips");
    host.innerHTML = list.length
      ? list.map(c => `<span class="chip chip--active">${esc(c.label)} <button class="chip__x" style="background:none;border:0;color:#fff;font:inherit;cursor:pointer" onclick="clearFilter('${c.clear}')" aria-label="Remove filter">✕</button></span>`).join("")
        + `<a class="chip chip--clear" href="shop.html">Clear all</a>`
      : "";
  }

  window.clearFilter = function (key) {
    if (key === "category") state.categories = [];
    else state[key] = "";
    if (key === "price") document.querySelectorAll("#priceFilters a").forEach(x => x.classList.remove("is-active"));
    syncUrl(); renderCategories(); updateHeading(); chips(); apply();
  };

  /* filtering */
  function inPrice(p) {
    switch (state.price) {
      case "under-200": return p.price < 200;
      case "200-400": return p.price >= 200 && p.price <= 400;
      case "400-600": return p.price > 400 && p.price <= 600;
      case "above-600": return p.price > 600;
      default: return true;
    }
  }
  function matches(p) {
    if (state.categories.length && !state.categories.includes(p.category)) return false;
    if (state.tag && p.tag !== state.tag) return false;
    if (!inPrice(p)) return false;
    if (state.q) {
      const hay = (p.name + " " + p.desc + " " + categoryName(p.category) + " " + (p.details || []).join(" ")).toLowerCase();
      const words = state.q.toLowerCase().split(/\s+/).filter(Boolean);
      if (!words.every(w => hay.includes(w))) return false;
    }
    return true;
  }
  function sortList(list) {
    const copy = list.slice();
    switch (state.sort) {
      case "price-asc": return copy.sort((a, b) => a.price - b.price);
      case "price-desc": return copy.sort((a, b) => b.price - a.price);
      case "rating": return copy.sort((a, b) => b.rating - a.rating);
      case "discount": return copy.sort((a, b) => (b.mrp - b.price) / b.mrp - (a.mrp - a.price) / a.mrp);
      case "new": return copy.sort((a, b) => (b.tag === "new") - (a.tag === "new"));
      default: return copy.sort((a, b) => (b.tag ? 1 : 0) - (a.tag ? 1 : 0));
    }
  }
  function apply() {
    const list = sortList(all.filter(matches));
    byId("resultCount").innerHTML = `<strong>${list.length}</strong> product${list.length === 1 ? "" : "s"} found`;
    renderGrid(byId("shopGrid"), list, "No products match this filter. Try clearing the search or choosing another category.");
  }

  updateHeading();
  renderCategories();
  chips();
  apply();
});
