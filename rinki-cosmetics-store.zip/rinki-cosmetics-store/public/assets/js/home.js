/* Homepage rendering + hero slider */
document.addEventListener("DOMContentLoaded", async () => {
  await loadCatalogue();
  const products = getProducts();

  /* categories */
  const catGrid = byId("categoryGrid");
  if (catGrid) {
    catGrid.innerHTML = CATEGORIES.map(c => {
      const count = products.filter(p => p.category === c.id).length;
      return `<a class="cat" href="shop.html?category=${c.id}">
        <div class="cat__media">${c.image
          ? `<img src="${esc(c.image)}" alt="${esc(c.name)} collection" loading="lazy">`
          : `<span class="cat__icon"><svg viewBox="0 0 24 24"><path d="${c.icon}"/></svg></span>`}</div>
        <h3>${esc(c.name)}</h3>
        <p>${count} product${count === 1 ? "" : "s"} · ${esc(c.tagline)}</p>
      </a>`;
    }).join("");
  }

  /* new arrivals */
  const arrivals = products.filter(p => p.tag === "new");
  renderGrid(byId("newArrivals"), arrivals.length ? arrivals : products.slice(0, 4), "No new arrivals yet.");

  /* trending + bestsellers */
  const trending = products.filter(p => p.tag === "trending" || p.tag === "bestseller");
  renderGrid(byId("trendingGrid"), (trending.length ? trending : products).slice(0, 8));

  /* hero product images */
  const HERO_SETS = [
    ["cosmetics-bridal-kit", "cosmetics-daily-kit", "cosmetics-perfume-mist"],
    ["vitamin-c-serum", "sunscreen-spf50", "hydra-face-wash"],
    ["onion-hair-oil", "keratin-shampoo", "hair-spa-mask"]
  ];
  document.querySelectorAll("[data-hero-set]").forEach(el => {
    const ids = HERO_SETS[Number(el.dataset.heroSet)] || [];
    let picks = ids.map(id => products.find(p => p.id === id && p.image)).filter(Boolean);
    if (!picks.length) picks = products.filter(p => p.image).slice(0, 3);
    el.innerHTML = picks.slice(0, 3).map((p, i) =>
      `<a class="hero__tile" href="product.html?id=${encodeURIComponent(p.id)}" aria-label="${esc(p.name)}">
        <img src="${esc(p.image)}" alt="${esc(p.name)}"${i ? ' loading="lazy"' : ""}>
      </a>`).join("");
  });

  /* hero slider */
  const slides = Array.from(document.querySelectorAll(".hero__slide"));
  const dots = Array.from(document.querySelectorAll("#heroDots button"));
  let index = 0, timer;
  function show(i) {
    index = (i + slides.length) % slides.length;
    slides.forEach((s, n) => s.classList.toggle("is-active", n === index));
    dots.forEach((d, n) => d.classList.toggle("is-active", n === index));
  }
  function start() { clearInterval(timer); timer = setInterval(() => show(index + 1), 6500); }
  dots.forEach((d, n) => d.addEventListener("click", () => { show(n); start(); }));
  if (slides.length > 1) start();
});
