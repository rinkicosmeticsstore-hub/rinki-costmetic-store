/* Rinki Beauty Parlour — admin dashboard (talks to the shop database API) */
(function () {
  const state = {
    products: [],
    editing: null,
    images: [],       // [{ src, file? }] — saved URLs and photos picked but not uploaded yet
    query: "",
    category: "",
    stock: "",
    setupRequired: false,
    loading: false
  };

  /* ---------- API helper ---------- */
  async function api(path, options) {
    const opts = Object.assign({ method: "GET", credentials: "same-origin" }, options || {});
    const headers = Object.assign({ Accept: "application/json" }, opts.headers || {});
    if (opts.body && !(opts.body instanceof FormData)) {
      headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(opts.body);
    }
    opts.headers = headers;
    let res;
    try {
      res = await fetch(path, opts);
    } catch (err) {
      throw new Error("No internet connection. Please check your network and try again.");
    }
    let data = null;
    try {
      data = await res.json();
    } catch (err) {
      data = null;
    }
    if (!res.ok) {
      const error = new Error((data && (data.error || data.message)) || "Something went wrong. Please try again.");
      error.status = res.status;
      throw error;
    }
    return data || {};
  }

  const $ = id => document.getElementById(id);
  function show(el) { if (el) el.classList.remove("hidden"); }
  function hide(el) { if (el) el.classList.add("hidden"); }
  function setError(el, message) {
    if (!el) return;
    if (message) {
      el.textContent = message;
      el.classList.remove("hidden");
    } else {
      el.textContent = "";
      el.classList.add("hidden");
    }
  }
  function busy(button, isBusy, label) {
    if (!button) return;
    if (isBusy) {
      button.dataset.label = button.textContent;
      button.textContent = label || "Please wait…";
      button.disabled = true;
    } else {
      button.textContent = button.dataset.label || button.textContent;
      button.disabled = false;
    }
  }

  /* category dropdowns come from the shared category list, so new categories
     added to the shop automatically appear in the admin panel */
  function populateCategories() {
    const options = CATEGORIES.map(c => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join("");
    const editor = $("pCategory");
    const filter = $("catFilter");
    if (editor) editor.innerHTML = options;
    if (filter) filter.innerHTML = `<option value="">All categories</option>` + options;
  }

  /* ---------- boot ---------- */
  document.addEventListener("DOMContentLoaded", () => {
    populateCategories();
    wireAuth();
    wireEditor();
    wireFilters();
    wirePassword();
    boot();
  });

  async function boot() {
    hide($("authScreen"));
    hide($("dashScreen"));
    show($("bootScreen"));
    try {
      const session = await api("/api/auth/session");
      state.setupRequired = !!session.setupRequired;
      hide($("bootScreen"));
      if (session.authed) {
        await enterDashboard(session.username);
      } else {
        showAuth(session.username);
      }
    } catch (err) {
      hide($("bootScreen"));
      showAuth("");
      setError($("authError"), err.message);
    }
  }

  function showAuth() {
    hide($("dashScreen"));
    show($("authScreen"));
    const setup = state.setupRequired;
    $("authTitle").textContent = setup ? "Create your admin account" : "Admin sign in";
    $("authSub").textContent = setup
      ? "This is a brand-new dashboard. Choose the username and password only you will use — it works on every device."
      : "Only the shop owner can open this dashboard.";
    $("authSubmit").textContent = setup ? "Create account & sign in" : "Sign in";
    $("authNote").textContent = setup
      ? "Use at least 8 characters. You can change these details later from Account & security."
      : "Forgot the password? It can be reset from the shop's server settings.";
    if (setup) show($("confirmWrap")); else hide($("confirmWrap"));
    $("authPass").setAttribute("autocomplete", setup ? "new-password" : "current-password");
    $("authUser").focus();
  }

  function wireAuth() {
    $("eyeBtn").addEventListener("click", () => {
      const input = $("authPass");
      const showIt = input.type === "password";
      input.type = showIt ? "text" : "password";
      $("eyeBtn").textContent = showIt ? "Hide" : "Show";
    });

    $("authForm").addEventListener("submit", async e => {
      e.preventDefault();
      setError($("authError"), "");
      const username = $("authUser").value.trim();
      const password = $("authPass").value;
      const submit = $("authSubmit");

      if (username.length < 3) return setError($("authError"), "Please enter your username.");
      if (password.length < 8 && state.setupRequired) return setError($("authError"), "Password must be at least 8 characters.");
      if (!password) return setError($("authError"), "Please enter your password.");

      const body = { username, password };
      let path = "/api/auth/login";
      if (state.setupRequired) {
        if (password !== $("authPass2").value) return setError($("authError"), "Both passwords must match.");
        path = "/api/auth/setup";
        body.password = password;
      }

      busy(submit, true, state.setupRequired ? "Creating…" : "Signing in…");
      try {
        const result = await api(path, { method: "POST", body });
        $("authPass").value = "";
        $("authPass2").value = "";
        await enterDashboard(result.username || username);
      } catch (err) {
        setError($("authError"), err.message);
        if (err.status === 409) state.setupRequired = false;
      } finally {
        busy(submit, false);
      }
    });

    $("logoutBtn").addEventListener("click", async () => {
      try {
        await api("/api/auth/logout", { method: "POST" });
      } catch (err) {
        /* signing out locally is enough */
      }
      state.products = [];
      $("admUser").textContent = "";
      hide($("admUser"));
      hide($("dashScreen"));
      hide($("logoutBtn"));
      state.setupRequired = false;
      showAuth();
      toast("Signed out");
    });
  }

  async function enterDashboard(username) {
    hide($("authScreen"));
    hide($("bootScreen"));
    show($("dashScreen"));
    show($("logoutBtn"));
    if (username) {
      $("admUser").textContent = username;
      show($("admUser"));
    }
    await loadProducts();
  }

  async function loadProducts(silent) {
    if (!silent) setError($("formError"), "");
    try {
      const data = await api("/api/admin/products");
      state.products = data.products || [];
      render();
    } catch (err) {
      if (err.status === 401) {
        hide($("dashScreen"));
        hide($("logoutBtn"));
        state.setupRequired = false;
        showAuth();
        setError($("authError"), "Your session expired. Please sign in again.");
        return;
      }
      if (!silent) toast(err.message);
    }
  }

  /* ---------- rendering ---------- */
  function render() {
    const list = state.products;
    $("statTotal").textContent = list.length;
    $("statVisible").textContent = list.filter(p => p.available).length;
    $("statInStock").textContent = list.filter(p => p.available && p.stock > 0).length;
    $("statOut").textContent = list.filter(p => p.stock <= 0).length;
    renderList();
  }

  function filtered() {
    const q = state.query.trim().toLowerCase();
    return state.products.filter(p => {
      if (state.category && p.category !== state.category) return false;
      if (state.stock === "in" && p.stock <= 0) return false;
      if (state.stock === "low" && !(p.stock > 0 && p.stock <= 5)) return false;
      if (state.stock === "out" && p.stock > 0) return false;
      if (state.stock === "hidden" && p.available) return false;
      if (q && !((p.name || "") + " " + (p.description || "")).toLowerCase().includes(q)) return false;
      return true;
    });
  }

  function stockLabel(p) {
    if (p.stock <= 0) return `<span class="adm-stock adm-stock--out">Out of stock</span>`;
    if (p.stock <= 5) return `<span class="adm-stock adm-stock--low">Only ${p.stock} left</span>`;
    return `<span class="adm-stock adm-stock--ok">${p.stock} in stock</span>`;
  }

  function renderList() {
    const list = filtered();
    $("listCount").textContent = list.length + (list.length === 1 ? " item" : " items");
    const host = $("productList");
    if (!list.length) {
      host.innerHTML = `<div class="adm-empty">
        <div class="adm-empty__icon">✦</div>
        <h3>${state.products.length ? "No products match this filter" : "Your shop is empty"}</h3>
        <p>${state.products.length ? "Try clearing the search or choosing another category." : "Add your first product and it will appear on the website right away."}</p>
        <button class="btn btn--primary btn--sm" type="button" data-action="new">+ Add a product</button>
      </div>`;
      return;
    }
    host.innerHTML = list.map(p => {
      const img = (p.images && p.images[0]) || "assets/hero/hero-1.svg";
      const off = p.mrp > p.price ? Math.round(((p.mrp - p.price) / p.mrp) * 100) : 0;
      return `<article class="adm-item${p.available ? "" : " is-hidden"}">
        <img class="adm-item__img" src="${esc(img)}" alt="${esc(p.name)}" loading="lazy">
        <div class="adm-item__main">
          <div class="adm-item__top">
            <h3>${esc(p.name)}</h3>
            ${p.tag ? `<span class="pill pill--tag pill--${esc(p.tag)} adm-pill">${tagLabel(p.tag)}</span>` : ""}
            ${p.available ? "" : `<span class="adm-pill adm-pill--muted">Hidden</span>`}
          </div>
          <p class="adm-item__meta">${esc(categoryName(p.category))} · ${p.images ? p.images.length : 0} photo${(p.images || []).length === 1 ? "" : "s"}</p>
          <div class="adm-item__prices">
            <strong>${money(p.price)}</strong>
            ${p.mrp > p.price ? `<s>${money(p.mrp)}</s><span class="adm-off">${off}% off</span>` : ""}
          </div>
        </div>
        <div class="adm-item__side">
          ${stockLabel(p)}
          <div class="adm-item__buttons">
            <button class="mini-btn" type="button" data-action="edit" data-id="${esc(p.id)}">Edit</button>
            <button class="mini-btn" type="button" data-action="toggle" data-id="${esc(p.id)}">${p.available ? "Hide" : "Show"}</button>
            <a class="mini-btn" href="product.html?id=${encodeURIComponent(p.id)}" target="_blank" rel="noopener">View</a>
            <button class="mini-btn mini-btn--danger" type="button" data-action="delete" data-id="${esc(p.id)}">Delete</button>
          </div>
        </div>
      </article>`;
    }).join("");
  }

  /* list interactions */
  function wireFilters() {
    $("searchInput").addEventListener("input", e => {
      state.query = e.target.value;
      renderList();
    });
    $("catFilter").addEventListener("change", e => {
      state.category = e.target.value;
      renderList();
    });
    $("stockFilter").addEventListener("change", e => {
      state.stock = e.target.value;
      renderList();
    });

    $("productList").addEventListener("click", async e => {
      const btn = e.target.closest("[data-action]");
      if (!btn) return;
      const action = btn.dataset.action;
      if (action === "new") return openEditor(null);
      const product = state.products.find(p => p.id === btn.dataset.id);
      if (!product) return;
      if (action === "edit") return openEditor(product);
      if (action === "toggle") {
        btn.disabled = true;
        try {
          await api("/api/admin/products/" + encodeURIComponent(product.id), {
            method: "PUT",
            body: { available: !product.available }
          });
          await loadProducts(true);
          toast(product.available ? "Product hidden from the website" : "Product is now live on the website");
        } catch (err) {
          toast(err.message);
          btn.disabled = false;
        }
        return;
      }
      if (action === "delete") {
        if (!confirm('Delete "' + product.name + '" permanently?\n\nIt will disappear from the website and its photos will be removed.')) return;
        btn.disabled = true;
        try {
          await api("/api/admin/products/" + encodeURIComponent(product.id), { method: "DELETE" });
          if (state.editing && state.editing.id === product.id) closeEditor();
          await loadProducts(true);
          toast("Product deleted");
        } catch (err) {
          toast(err.message);
          btn.disabled = false;
        }
      }
    });
  }

  /* ---------- editor ---------- */
  function wireEditor() {
    $("addBtn").addEventListener("click", () => openEditor(null));
    $("closeEditor").addEventListener("click", closeEditor);
    $("cancelBtn").addEventListener("click", closeEditor);
    $("productForm").addEventListener("submit", saveProduct);
    $("deleteBtn").addEventListener("click", () => {
      if (state.editing) deleteCurrent(state.editing);
    });
    $("imageInput").addEventListener("change", e => {
      const files = Array.from(e.target.files || []);
      const room = 6 - state.images.length;
      if (files.length > room) toast("You can keep up to 6 photos per product");
      files.slice(0, Math.max(0, room)).forEach(file => {
        if (!/^image\//.test(file.type)) return toast("Please choose image files only");
        if (file.size > 4 * 1024 * 1024) return toast("Each photo must be under 4 MB");
        state.images.push({ src: URL.createObjectURL(file), file: file });
      });
      e.target.value = "";
      renderThumbs();
    });
    $("thumbs").addEventListener("click", e => {
      const btn = e.target.closest("[data-remove]");
      if (!btn) return;
      removeImage(Number(btn.dataset.remove));
    });
  }

  function openEditor(product) {
    state.editing = product || null;
    state.images = product ? (product.images || []).map(src => ({ src: src })) : [];
    setError($("formError"), "");

    $("pId").value = product ? product.id : "";
    $("pName").value = product ? product.name : "";
    $("pCategory").value = product ? product.category : "makeup";
    $("pTag").value = product ? product.tag || "" : "";
    $("pPrice").value = product ? product.price : "";
    $("pMrp").value = product && product.mrp ? product.mrp : "";
    $("pStock").value = product ? product.stock : 12;
    $("pRating").value = product ? product.rating : "";
    $("pReviews").value = product && product.reviews ? product.reviews : "";
    $("pDesc").value = product ? product.description || "" : "";
    $("pDetails").value = product ? (product.details || []).join("\n") : "";
    $("pAvailable").checked = product ? !!product.available : true;

    $("editorTitle").textContent = product ? "Edit product" : "Add new product";
    $("saveBtn").textContent = product ? "Save changes" : "Save product";
    if (product) show($("deleteBtn")); else hide($("deleteBtn"));
    renderThumbs();

    show($("editorCard"));
    $("editorCard").scrollIntoView({ behavior: "smooth", block: "start" });
    setTimeout(() => $("pName").focus({ preventScroll: true }), 300);
  }

  function renderThumbs() {
    const host = $("thumbs");
    if (!host) return;
    host.innerHTML = state.images.map((image, i) => `
      <div class="adm-thumb${i === 0 ? " is-main" : ""}">
        <img src="${esc(image.src)}" alt="Product photo ${i + 1}">
        ${i === 0 ? `<span class="adm-thumb__tag">Main</span>` : ""}
        <button class="adm-thumb__x" type="button" data-remove="${i}" aria-label="Remove photo">✕</button>
      </div>`).join("") || `<p class="adm-muted adm-thumb__none">No photos yet — add at least one so the product looks good on the shop page.</p>`;
    $("imageInput").disabled = state.images.length >= 6;
  }

  function removeImage(index) {
    state.images.splice(index, 1);
    renderThumbs();
  }

  function closeEditor() {
    hide($("editorCard"));
    state.editing = null;
    state.images = [];
    setError($("formError"), "");
  }

  async function saveProduct(e) {
    e.preventDefault();
    setError($("formError"), "");
    const name = $("pName").value.trim();
    const price = Number($("pPrice").value);
    const desc = $("pDesc").value.trim();
    const stock = Number($("pStock").value);

    if (name.length < 2) return setError($("formError"), "Please enter the product name.");
    if (!(price > 0)) return setError($("formError"), "Please enter a valid selling price.");
    if (!Number.isFinite(stock) || stock < 0) return setError($("formError"), "Please enter the stock quantity (0 or more).");
    if (desc.length < 3) return setError($("formError"), "Please add a short description.");

    const saveBtn = $("saveBtn");
    const newPhotos = state.images.filter(image => image.file);
    busy(saveBtn, true, newPhotos.length ? "Uploading photos…" : "Saving…");

    try {
      let uploadedUrls = [];
      if (newPhotos.length) {
        const form = new FormData();
        newPhotos.forEach(image => form.append("files", image.file));
        const uploaded = await api("/api/admin/uploads", { method: "POST", body: form });
        uploadedUrls = uploaded.urls || [];
        busy(saveBtn, true, "Saving…");
      }
      let fileIndex = 0;
      const images = state.images
        .map(image => (image.file ? uploadedUrls[fileIndex++] : image.src))
        .filter(Boolean)
        .slice(0, 6);
      if (!images.length) {
        images.push("assets/hero/hero-1.svg");
      }

      const payload = {
        name,
        category: $("pCategory").value,
        tag: $("pTag").value,
        price: Math.round(price),
        mrp: Math.round(Number($("pMrp").value) || price),
        stock: Math.round(stock),
        rating: Number($("pRating").value) || 4.5,
        reviews: Math.round(Number($("pReviews").value) || 0),
        description: desc,
        details: $("pDetails").value.split("\n").map(s => s.trim()).filter(Boolean),
        images,
        available: $("pAvailable").checked
      };

      const editingId = $("pId").value;
      if (editingId) {
        await api("/api/admin/products/" + encodeURIComponent(editingId), { method: "PUT", body: payload });
        toast("Product updated — the website is already showing the change");
      } else {
        await api("/api/admin/products", { method: "POST", body: payload });
        toast("Product added to your shop");
      }
      closeEditor();
      await loadProducts(true);
    } catch (err) {
      if (err.status === 401) {
        hide($("dashScreen"));
        state.setupRequired = false;
        showAuth();
        setError($("authError"), "Your session expired. Please sign in again.");
      } else {
        setError($("formError"), err.message);
      }
    } finally {
      busy(saveBtn, false);
    }
  }

  async function deleteCurrent(product) {
    if (!confirm('Delete "' + product.name + '" permanently?\n\nIt will disappear from the website.')) return;
    const btn = $("deleteBtn");
    btn.disabled = true;
    try {
      await api("/api/admin/products/" + encodeURIComponent(product.id), { method: "DELETE" });
      closeEditor();
      await loadProducts(true);
      toast("Product deleted");
    } catch (err) {
      setError($("formError"), err.message);
    } finally {
      btn.disabled = false;
    }
  }

  /* ---------- password ---------- */
  function wirePassword() {
    $("passForm").addEventListener("submit", async e => {
      e.preventDefault();
      setError($("passError"), "");
      const currentPassword = $("curPass").value;
      const newPassword = $("newPass").value;
      if (!currentPassword) return setError($("passError"), "Please enter your current password.");
      if (newPassword.length < 8) return setError($("passError"), "New password must be at least 8 characters.");
      if (newPassword !== $("newPass2").value) return setError($("passError"), "Both new passwords must match.");

      const btn = $("passBtn");
      busy(btn, true, "Updating…");
      try {
        await api("/api/auth/password", { method: "POST", body: { currentPassword, newPassword } });
        $("passForm").reset();
        toast("Password updated");
      } catch (err) {
        setError($("passError"), err.message);
      } finally {
        busy(btn, false);
      }
    });
  }
})();
