-- ============================================================
-- Rinki Cosmetics Store — database schema (Cloudflare D1 / SQLite)
-- The Worker creates these tables automatically on first request
-- (see SCHEMA in worker/index.js). This file is the reference copy
-- so the schema can be inspected or applied manually.
--
-- Local:       npx wrangler d1 execute rinki-catalogue --local --file=schema.sql
-- Production:  npx wrangler d1 execute rinki-catalogue --remote --file=schema.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL,                 -- makeup | skincare | haircare | accessories | fashion | gifts | cosmetics | offers
  price INTEGER NOT NULL,                 -- selling price in rupees
  mrp INTEGER NOT NULL DEFAULT 0,         -- original price in rupees (for the discount badge)
  rating REAL NOT NULL DEFAULT 4.5,
  reviews INTEGER NOT NULL DEFAULT 0,
  tag TEXT NOT NULL DEFAULT '',           -- '' | new | trending | bestseller
  description TEXT NOT NULL DEFAULT '',
  details TEXT NOT NULL DEFAULT '[]',     -- JSON array of short strings
  images TEXT NOT NULL DEFAULT '[]',      -- JSON array of image paths (assets/... , /media/... or https://...)
  stock INTEGER NOT NULL DEFAULT 0,
  available INTEGER NOT NULL DEFAULT 1,   -- 1 = shown in the shop, 0 = hidden
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS admins (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  pass_hash TEXT NOT NULL,                -- PBKDF2-SHA256 derived key (hex)
  pass_salt TEXT NOT NULL,                -- random salt (hex)
  iterations INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,            -- SHA-256 of the session cookie value
  admin_id INTEGER NOT NULL,
  created_at INTEGER NOT NULL,            -- ms since epoch
  expires_at INTEGER NOT NULL             -- ms since epoch
);

CREATE TABLE IF NOT EXISTS login_attempts (
  key TEXT PRIMARY KEY,                   -- client IP address
  count INTEGER NOT NULL,
  window_start INTEGER NOT NULL           -- ms since epoch
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_products_available ON products (available, sort_order);
