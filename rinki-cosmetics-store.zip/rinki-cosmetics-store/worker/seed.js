/* Generated from public/assets/js/data.js by tools/build-seed.mjs — do not edit by hand */
export const SAMPLE_PRODUCTS = [
  {
    "id": "velvet-matte-lipstick",
    "name": "Velvet Matte Lipstick",
    "category": "makeup",
    "price": 299,
    "mrp": 499,
    "rating": 4.6,
    "reviews": 214,
    "tag": "bestseller",
    "desc": "A creamy, full-coverage matte lipstick that stays put for up to 12 hours without drying your lips.",
    "details": [
      "Transfer-proof matte finish",
      "Enriched with vitamin E & jojoba oil",
      "12 hour long wear",
      "Available in 8 Indian skin-friendly shades"
    ],
    "image": "assets/products/velvet-matte-lipstick.svg",
    "images": [
      "assets/products/velvet-matte-lipstick.svg"
    ],
    "stock": 12
  },
  {
    "id": "glow-foundation",
    "name": "Silk Glow Liquid Foundation",
    "category": "makeup",
    "price": 449,
    "mrp": 699,
    "rating": 4.4,
    "reviews": 168,
    "tag": "trending",
    "desc": "Lightweight buildable coverage with a natural, dewy glow. Blends effortlessly into the skin.",
    "details": [
      "Medium to full coverage",
      "SPF 15 sun protection",
      "Oil-free, non-comedogenic",
      "6 shades for Indian skin tones"
    ],
    "image": "assets/products/glow-foundation.svg",
    "images": [
      "assets/products/glow-foundation.svg"
    ],
    "stock": 12
  },
  {
    "id": "intense-kajal",
    "name": "Intense Black Kajal",
    "category": "makeup",
    "price": 149,
    "mrp": 249,
    "rating": 4.7,
    "reviews": 389,
    "tag": "bestseller",
    "desc": "Smudge-proof, waterproof kajal with a rich black pigment that defines your eyes in one stroke.",
    "details": [
      "Waterproof & smudge-proof",
      "Retractable twist-up pencil",
      "Ophthalmologist tested",
      "Lasts up to 10 hours"
    ],
    "image": "assets/products/intense-kajal.svg",
    "images": [
      "assets/products/intense-kajal.svg"
    ],
    "stock": 12
  },
  {
    "id": "oil-control-compact",
    "name": "Oil Control Compact Powder",
    "category": "makeup",
    "price": 249,
    "mrp": 399,
    "rating": 4.3,
    "reviews": 142,
    "tag": "",
    "desc": "Fine, silky powder that controls shine and sets makeup for a fresh, matte look all day.",
    "details": [
      "Mattifies for up to 8 hours",
      "Lightweight, no cakey finish",
      "Built-in mirror & puff",
      "Suitable for all skin types"
    ],
    "image": "assets/products/oil-control-compact.svg",
    "images": [
      "assets/products/oil-control-compact.svg"
    ],
    "stock": 12
  },
  {
    "id": "rose-eyeshadow-palette",
    "name": "Rose Nude Eyeshadow Palette",
    "category": "makeup",
    "price": 599,
    "mrp": 999,
    "rating": 4.5,
    "reviews": 97,
    "tag": "new",
    "desc": "Twelve blendable rose and nude shades — mattes, shimmers and one glossy highlight for every occasion.",
    "details": [
      "12 highly pigmented shades",
      "Buttery, blendable texture",
      "Travel friendly case with mirror",
      "Cruelty-free & vegan"
    ],
    "image": "assets/products/rose-eyeshadow-palette.svg",
    "images": [
      "assets/products/rose-eyeshadow-palette.svg"
    ],
    "stock": 12
  },
  {
    "id": "volume-mascara",
    "name": "Volume Boost Mascara",
    "category": "makeup",
    "price": 279,
    "mrp": 449,
    "rating": 4.4,
    "reviews": 205,
    "tag": "",
    "desc": "A clump-free volumising mascara with a tapered wand that lifts and separates every lash.",
    "details": [
      "3x volume in one coat",
      "Water resistant formula",
      "Easy removal with warm water",
      "Ophthalmologist tested"
    ],
    "image": "assets/products/volume-mascara.svg",
    "images": [
      "assets/products/volume-mascara.svg"
    ],
    "stock": 12
  },
  {
    "id": "cheek-blush",
    "name": "Soft Cheek Blush",
    "category": "makeup",
    "price": 199,
    "mrp": 349,
    "rating": 4.3,
    "reviews": 88,
    "tag": "",
    "desc": "Silky blush that melts into the skin for a natural, healthy flush of colour.",
    "details": [
      "Buildable satin finish",
      "Talc-free pressed powder",
      "Long lasting colour",
      "4 shades available"
    ],
    "image": "assets/products/cheek-blush.svg",
    "images": [
      "assets/products/cheek-blush.svg"
    ],
    "stock": 12
  },
  {
    "id": "gel-nail-polish",
    "name": "Glossy Gel Nail Polish",
    "category": "makeup",
    "price": 129,
    "mrp": 199,
    "rating": 4.2,
    "reviews": 156,
    "tag": "new",
    "desc": "High-shine gel finish nail paint that dries fast and stays chip-free for over a week.",
    "details": [
      "Glossy gel-like finish",
      "Quick drying formula",
      "No UV lamp needed",
      "12 trendy shades"
    ],
    "image": "assets/products/gel-nail-polish.svg",
    "images": [
      "assets/products/gel-nail-polish.svg"
    ],
    "stock": 12
  },
  {
    "id": "vitamin-c-serum",
    "name": "Radiance Vitamin C Serum 20%",
    "category": "skincare",
    "price": 549,
    "mrp": 899,
    "rating": 4.7,
    "reviews": 312,
    "tag": "bestseller",
    "desc": "A potent vitamin C serum with hyaluronic acid that fades dark spots and evens out skin tone.",
    "details": [
      "20% stabilised vitamin C",
      "Brightens dull skin in 4 weeks",
      "Lightweight, non-sticky",
      "Fragrance-free · 30 ml"
    ],
    "image": "assets/products/vitamin-c-serum.svg",
    "images": [
      "assets/products/vitamin-c-serum.svg"
    ],
    "stock": 12
  },
  {
    "id": "hydra-face-wash",
    "name": "Hydra Fresh Face Wash",
    "category": "skincare",
    "price": 199,
    "mrp": 329,
    "rating": 4.5,
    "reviews": 276,
    "tag": "trending",
    "desc": "A gentle gel face wash that removes dirt and excess oil without stripping your skin's moisture.",
    "details": [
      "Sulphate & paraben free",
      "pH balanced formula",
      "With aloe vera extract",
      "For normal to oily skin · 100 ml"
    ],
    "image": "assets/products/hydra-face-wash.svg",
    "images": [
      "assets/products/hydra-face-wash.svg"
    ],
    "stock": 12
  },
  {
    "id": "aloe-gel-moisturizer",
    "name": "Aloe Vera Gel Moisturizer",
    "category": "skincare",
    "price": 249,
    "mrp": 399,
    "rating": 4.6,
    "reviews": 190,
    "tag": "",
    "desc": "Cooling aloe gel with mint that hydrates deeply and calms redness, perfect for Indian summers.",
    "details": [
      "99% pure aloe extract",
      "Non-greasy, quick absorbing",
      "Soothes sunburnt skin",
      "200 g tub"
    ],
    "image": "assets/products/aloe-gel-moisturizer.svg",
    "images": [
      "assets/products/aloe-gel-moisturizer.svg"
    ],
    "stock": 12
  },
  {
    "id": "sunscreen-spf50",
    "name": "Sun Shield SPF 50 Gel Sunscreen",
    "category": "skincare",
    "price": 399,
    "mrp": 599,
    "rating": 4.6,
    "reviews": 341,
    "tag": "bestseller",
    "desc": "Broad spectrum SPF 50 PA+++ gel sunscreen that protects against tan, spots and premature ageing.",
    "details": [
      "No white cast, matte finish",
      "UVA + UVB protection",
      "Water resistant",
      "Suitable for daily use · 50 g"
    ],
    "image": "assets/products/sunscreen-spf50.svg",
    "images": [
      "assets/products/sunscreen-spf50.svg"
    ],
    "stock": 12
  },
  {
    "id": "ubtan-face-pack",
    "name": "Herbal Ubtan Face Pack",
    "category": "skincare",
    "price": 179,
    "mrp": 299,
    "rating": 4.4,
    "reviews": 121,
    "tag": "",
    "desc": "Traditional ubtan blend of turmeric, sandalwood and gram flour for an instant natural glow.",
    "details": [
      "100% natural ingredients",
      "Detan & brightening",
      "No added preservatives",
      "100 g jar"
    ],
    "image": "assets/products/ubtan-face-pack.svg",
    "images": [
      "assets/products/ubtan-face-pack.svg"
    ],
    "stock": 12
  },
  {
    "id": "rose-water-toner",
    "name": "Pure Rose Water Toner",
    "category": "skincare",
    "price": 159,
    "mrp": 249,
    "rating": 4.5,
    "reviews": 178,
    "tag": "new",
    "desc": "Steam distilled rose water that tones, refreshes and preps the skin before moisturiser.",
    "details": [
      "Pure gulab jal, no alcohol",
      "Tightens pores",
      "Can be used as a face mist",
      "200 ml spray bottle"
    ],
    "image": "assets/products/rose-water-toner.svg",
    "images": [
      "assets/products/rose-water-toner.svg"
    ],
    "stock": 12
  },
  {
    "id": "under-eye-gel",
    "name": "Under Eye Brightening Gel",
    "category": "skincare",
    "price": 289,
    "mrp": 449,
    "rating": 4.3,
    "reviews": 86,
    "tag": "",
    "desc": "Cooling caffeine gel that reduces puffiness and dark circles with a soothing roller tip.",
    "details": [
      "Caffeine + cucumber extract",
      "Reduces puffiness in 2 weeks",
      "Cooling metal roller applicator",
      "15 ml"
    ],
    "image": "assets/products/under-eye-gel.svg",
    "images": [
      "assets/products/under-eye-gel.svg"
    ],
    "stock": 12
  },
  {
    "id": "onion-hair-oil",
    "name": "Onion & Curry Leaf Hair Oil",
    "category": "haircare",
    "price": 249,
    "mrp": 399,
    "rating": 4.5,
    "reviews": 264,
    "tag": "trending",
    "desc": "A traditional herbal oil that strengthens roots, reduces hair fall and supports new growth.",
    "details": [
      "Cold pressed onion seed oil",
      "9 herbal extracts",
      "Non-sticky finish",
      "200 ml"
    ],
    "image": "assets/products/onion-hair-oil.svg",
    "images": [
      "assets/products/onion-hair-oil.svg"
    ],
    "stock": 12
  },
  {
    "id": "keratin-shampoo",
    "name": "Keratin Smooth Shampoo",
    "category": "haircare",
    "price": 299,
    "mrp": 499,
    "rating": 4.6,
    "reviews": 231,
    "tag": "bestseller",
    "desc": "Salon-style smoothing shampoo with keratin that tames frizz and adds a healthy shine.",
    "details": [
      "Sulphate-free cleansing",
      "Frizz control for 48 hours",
      "Safe for coloured hair",
      "300 ml"
    ],
    "image": "assets/products/keratin-shampoo.svg",
    "images": [
      "assets/products/keratin-shampoo.svg"
    ],
    "stock": 12
  },
  {
    "id": "silk-conditioner",
    "name": "Silk Repair Conditioner",
    "category": "haircare",
    "price": 289,
    "mrp": 479,
    "rating": 4.4,
    "reviews": 149,
    "tag": "",
    "desc": "Deeply conditioning formula with silk protein that detangles and repairs dry, damaged ends.",
    "details": [
      "Detangles instantly",
      "Repairs split ends",
      "Light floral fragrance",
      "300 ml"
    ],
    "image": "assets/products/silk-conditioner.svg",
    "images": [
      "assets/products/silk-conditioner.svg"
    ],
    "stock": 12
  },
  {
    "id": "hair-serum",
    "name": "Frizz Control Hair Serum",
    "category": "haircare",
    "price": 349,
    "mrp": 549,
    "rating": 4.5,
    "reviews": 118,
    "tag": "new",
    "desc": "Lightweight serum with argan oil that smooths flyaways and gives a glossy, finished look.",
    "details": [
      "With Moroccan argan oil",
      "Heat protection up to 200°C",
      "Non-greasy, weightless",
      "100 ml pump bottle"
    ],
    "image": "assets/products/hair-serum.svg",
    "images": [
      "assets/products/hair-serum.svg"
    ],
    "stock": 12
  },
  {
    "id": "hair-spa-mask",
    "name": "Deep Nourish Hair Spa Mask",
    "category": "haircare",
    "price": 329,
    "mrp": 529,
    "rating": 4.4,
    "reviews": 94,
    "tag": "",
    "desc": "Weekly hair spa treatment with shea butter that restores softness to dry, brittle hair.",
    "details": [
      "Shea butter + almond oil",
      "Deep conditioning in 10 minutes",
      "Makes hair salon-soft",
      "200 g jar"
    ],
    "image": "assets/products/hair-spa-mask.svg",
    "images": [
      "assets/products/hair-spa-mask.svg"
    ],
    "stock": 12
  },
  {
    "id": "makeup-brush-set",
    "name": "7-Piece Makeup Brush Set",
    "category": "accessories",
    "price": 499,
    "mrp": 899,
    "rating": 4.5,
    "reviews": 203,
    "tag": "trending",
    "desc": "A complete face and eye brush set with ultra-soft synthetic bristles for a flawless, streak-free finish.",
    "details": [
      "7 face & eye brushes",
      "Cruelty-free synthetic bristles",
      "Wooden handle with travel pouch",
      "Easy to clean"
    ],
    "image": "assets/products/makeup-brush-set.svg",
    "images": [
      "assets/products/makeup-brush-set.svg"
    ],
    "stock": 12
  },
  {
    "id": "beauty-blender",
    "name": "Soft Beauty Blender Sponge (Pack of 2)",
    "category": "accessories",
    "price": 129,
    "mrp": 249,
    "rating": 4.4,
    "reviews": 187,
    "tag": "",
    "desc": "Latex-free blending sponges that give an airbrushed base, wet or dry.",
    "details": [
      "Pack of 2 sponges",
      "Latex-free & odour-free",
      "Use damp for dewy finish",
      "Includes holder"
    ],
    "image": "assets/products/beauty-blender.svg",
    "images": [
      "assets/products/beauty-blender.svg"
    ],
    "stock": 12
  },
  {
    "id": "eyelash-curler",
    "name": "Stainless Steel Eyelash Curler",
    "category": "accessories",
    "price": 159,
    "mrp": 299,
    "rating": 4.2,
    "reviews": 74,
    "tag": "",
    "desc": "Precision eyelash curler with a soft silicone pad for a comfortable, long-lasting curl.",
    "details": [
      "Stainless steel body",
      "Replacement silicone pad included",
      "Fits all eye shapes",
      "Travel friendly"
    ],
    "image": "assets/products/eyelash-curler.svg",
    "images": [
      "assets/products/eyelash-curler.svg"
    ],
    "stock": 12
  },
  {
    "id": "vanity-mirror",
    "name": "LED Vanity Table Mirror",
    "category": "accessories",
    "price": 799,
    "mrp": 1299,
    "rating": 4.6,
    "reviews": 63,
    "tag": "new",
    "desc": "A foldable vanity mirror with LED lights and three brightness modes for flawless makeup every time.",
    "details": [
      "Touch control LED lights",
      "3 brightness settings",
      "USB rechargeable",
      "Detachable 10x zoom mirror"
    ],
    "image": "assets/products/vanity-mirror.svg",
    "images": [
      "assets/products/vanity-mirror.svg"
    ],
    "stock": 12
  },
  {
    "id": "scrunchies-set",
    "name": "Satin Scrunchie Set (6 Pcs)",
    "category": "accessories",
    "price": 199,
    "mrp": 349,
    "rating": 4.5,
    "reviews": 132,
    "tag": "",
    "desc": "Soft satin scrunchies in pretty pastel shades that hold hair gently without breakage.",
    "details": [
      "Set of 6 pastel shades",
      "Gentle on hair & crease-free",
      "Premium satin finish",
      "Perfect gifting option"
    ],
    "image": "assets/products/scrunchies-set.svg",
    "images": [
      "assets/products/scrunchies-set.svg"
    ],
    "stock": 12
  },
  {
    "id": "manicure-kit",
    "name": "Manicure & Pedicure Kit",
    "category": "accessories",
    "price": 449,
    "mrp": 749,
    "rating": 4.3,
    "reviews": 58,
    "tag": "",
    "desc": "Complete 12-piece nail care kit in a zip case for salon-like grooming at home.",
    "details": [
      "12 stainless steel tools",
      "Zipper travel case",
      "Rust resistant",
      "Great gift for women"
    ],
    "image": "assets/products/manicure-kit.svg",
    "images": [
      "assets/products/manicure-kit.svg"
    ],
    "stock": 12
  },
  {
    "id": "makeup-pouch",
    "name": "Travel Makeup Pouch",
    "category": "accessories",
    "price": 299,
    "mrp": 499,
    "rating": 4.4,
    "reviews": 91,
    "tag": "trending",
    "desc": "Spacious, water-resistant pouch with compartments that keeps your essentials organised.",
    "details": [
      "Water resistant fabric",
      "Multiple zip compartments",
      "Wipe-clean inner lining",
      "Fits in any handbag"
    ],
    "image": "assets/products/makeup-pouch.svg",
    "images": [
      "assets/products/makeup-pouch.svg"
    ],
    "stock": 12
  },
  {
    "id": "jade-roller",
    "name": "Jade Roller & Gua Sha Set",
    "category": "accessories",
    "price": 399,
    "mrp": 699,
    "rating": 4.5,
    "reviews": 77,
    "tag": "new",
    "desc": "Natural jade facial roller and gua sha massager to de-puff, sculpt and boost circulation.",
    "details": [
      "100% natural jade stone",
      "Reduces puffiness & fine lines",
      "Includes storage pouch",
      "Cooling massage effect"
    ],
    "image": "assets/products/jade-roller.svg",
    "images": [
      "assets/products/jade-roller.svg"
    ],
    "stock": 12
  },
  {
    "id": "fashion-cotton-kurti",
    "name": "Cotton Anarkali Kurti",
    "category": "fashion",
    "price": 899,
    "mrp": 1499,
    "rating": 4.5,
    "reviews": 64,
    "tag": "new",
    "desc": "Soft cotton Anarkali kurti with a flattering flared cut — comfortable enough for daily wear and pretty enough for festivals.",
    "details": [
      "100% breathable cotton",
      "Anarkali flare with side pockets",
      "Machine washable, colour-fast print",
      "Sizes S to XXL"
    ],
    "image": "assets/products/fashion-cotton-kurti.svg",
    "images": [
      "assets/products/fashion-cotton-kurti.svg"
    ],
    "stock": 12
  },
  {
    "id": "fashion-floral-saree",
    "name": "Floral Georgette Saree",
    "category": "fashion",
    "price": 1299,
    "mrp": 2199,
    "rating": 4.6,
    "reviews": 41,
    "tag": "trending",
    "desc": "Light georgette saree with a delicate floral print and matching unstitched blouse piece — easy to drape all day.",
    "details": [
      "5.5 m saree with blouse piece",
      "Soft, flowy georgette",
      "Hand-finished piping border",
      "Dry clean recommended"
    ],
    "image": "assets/products/fashion-floral-saree.svg",
    "images": [
      "assets/products/fashion-floral-saree.svg"
    ],
    "stock": 12
  },
  {
    "id": "fashion-handloom-dupatta",
    "name": "Handloom Cotton Dupatta",
    "category": "fashion",
    "price": 499,
    "mrp": 899,
    "rating": 4.4,
    "reviews": 38,
    "tag": "",
    "desc": "Handwoven cotton dupatta with a fine zari border — the easiest way to dress up a plain kurti or suit.",
    "details": [
      "Handloom woven cotton",
      "2.5 m length with tassels",
      "Zari border detail",
      "Gentle hand wash"
    ],
    "image": "assets/products/fashion-handloom-dupatta.svg",
    "images": [
      "assets/products/fashion-handloom-dupatta.svg"
    ],
    "stock": 12
  },
  {
    "id": "gifts-beauty-hamper",
    "name": "Beauty Gift Hamper",
    "category": "gifts",
    "price": 999,
    "mrp": 1599,
    "rating": 4.7,
    "reviews": 52,
    "tag": "bestseller",
    "desc": "A ready-to-gift hamper with a lipstick, kajal, face wash and body lotion packed in a pretty keepsake box.",
    "details": [
      "4 full-size beauty essentials",
      "Premium gift box with ribbon",
      "Free handwritten gift note",
      "Perfect for birthdays & festivals"
    ],
    "image": "assets/products/gifts-beauty-hamper.svg",
    "images": [
      "assets/products/gifts-beauty-hamper.svg"
    ],
    "stock": 12
  },
  {
    "id": "gifts-jewellery-box",
    "name": "Jewellery Gift Box",
    "category": "gifts",
    "price": 699,
    "mrp": 1099,
    "rating": 4.5,
    "reviews": 33,
    "tag": "new",
    "desc": "An elegant necklace set in a velvet-lined gift box — a thoughtful gift for weddings, karwa chauth and anniversaries.",
    "details": [
      "Gold-tone necklace set",
      "Velvet-lined jewellery box",
      "Skin-friendly, nickel free",
      "Gift wrapped free"
    ],
    "image": "assets/products/gifts-jewellery-box.svg",
    "images": [
      "assets/products/gifts-jewellery-box.svg"
    ],
    "stock": 12
  },
  {
    "id": "gifts-candle-set",
    "name": "Scented Candle Gift Set",
    "category": "gifts",
    "price": 549,
    "mrp": 899,
    "rating": 4.4,
    "reviews": 27,
    "tag": "",
    "desc": "Three hand-poured soy candles in rose, vanilla and sandalwood — a calm, lovely gift for any occasion.",
    "details": [
      "Set of 3 glass candles",
      "Natural soy wax, cotton wick",
      "Burns up to 20 hours each",
      "Reusable glass jars"
    ],
    "image": "assets/products/gifts-candle-set.svg",
    "images": [
      "assets/products/gifts-candle-set.svg"
    ],
    "stock": 12
  },
  {
    "id": "cosmetics-daily-kit",
    "name": "Daily Glow Makeup Kit",
    "category": "cosmetics",
    "price": 749,
    "mrp": 1199,
    "rating": 4.5,
    "reviews": 58,
    "tag": "trending",
    "desc": "Everything for a five-minute everyday face: compact, kajal, lipstick and blush in one handy kit.",
    "details": [
      "4 everyday essentials in one box",
      "Buildable, natural finish",
      "Travel-friendly sizes",
      "Suitable for all skin tones"
    ],
    "image": "assets/products/cosmetics-daily-kit.svg",
    "images": [
      "assets/products/cosmetics-daily-kit.svg"
    ],
    "stock": 12
  },
  {
    "id": "cosmetics-bridal-kit",
    "name": "Bridal Beauty Kit",
    "category": "cosmetics",
    "price": 1499,
    "mrp": 2499,
    "rating": 4.6,
    "reviews": 22,
    "tag": "new",
    "desc": "A complete bridal-ready set with foundation, palette, kajal, mascara and setting spray — salon results at home.",
    "details": [
      "6-piece bridal collection",
      "Long-wear, photo-friendly finish",
      "Includes applicators & pouch",
      "Great for wedding season"
    ],
    "image": "assets/products/cosmetics-bridal-kit.svg",
    "images": [
      "assets/products/cosmetics-bridal-kit.svg"
    ],
    "stock": 12
  },
  {
    "id": "cosmetics-perfume-mist",
    "name": "Perfume & Body Mist Set",
    "category": "cosmetics",
    "price": 599,
    "mrp": 999,
    "rating": 4.3,
    "reviews": 45,
    "tag": "",
    "desc": "A light floral perfume with a matching body mist that keeps you fresh from morning to evening.",
    "details": [
      "Eau de parfum 30 ml + mist 100 ml",
      "Rose, jasmine & vanilla notes",
      "Long lasting 6–8 hours",
      "Alcohol-free mist"
    ],
    "image": "assets/products/cosmetics-perfume-mist.svg",
    "images": [
      "assets/products/cosmetics-perfume-mist.svg"
    ],
    "stock": 12
  },
  {
    "id": "offer-kajal-99",
    "name": "₹99 Kajal & Liner Duo",
    "category": "offers",
    "price": 99,
    "mrp": 249,
    "rating": 4.4,
    "reviews": 96,
    "tag": "bestseller",
    "desc": "A smudge-proof kajal with a fine liner tip — one stroke definition for everyday eyes, now at a flat ₹99.",
    "details": [
      "2-in-1 kajal + liner",
      "Smudge-proof, waterproof",
      "Deep black matte finish",
      "Offer price ₹99 only"
    ],
    "image": "assets/products/offer-kajal-99.svg",
    "images": [
      "assets/products/offer-kajal-99.svg"
    ],
    "stock": 12
  },
  {
    "id": "offer-nail-polish-99",
    "name": "₹99 Glossy Nail Polish",
    "category": "offers",
    "price": 99,
    "mrp": 199,
    "rating": 4.2,
    "reviews": 74,
    "tag": "trending",
    "desc": "Quick-dry glossy nail polish in a fresh rose shade that lasts up to 7 days without chipping.",
    "details": [
      "Quick dry in 60 seconds",
      "Chip-resistant shine",
      "Rose pink shade",
      "Offer price ₹99 only"
    ],
    "image": "assets/products/offer-nail-polish-99.svg",
    "images": [
      "assets/products/offer-nail-polish-99.svg"
    ],
    "stock": 12
  },
  {
    "id": "offer-lip-balm-99",
    "name": "₹99 Tinted Lip Balm",
    "category": "offers",
    "price": 99,
    "mrp": 199,
    "rating": 4.5,
    "reviews": 58,
    "tag": "new",
    "desc": "A moisturising tinted lip balm with shea butter and vitamin E — soft pink glow with all-day comfort.",
    "details": [
      "Shea butter + vitamin E",
      "Natural pink tint",
      "No sticky feel",
      "Offer price ₹99 only"
    ],
    "image": "assets/products/offer-lip-balm-99.svg",
    "images": [
      "assets/products/offer-lip-balm-99.svg"
    ],
    "stock": 12
  }
];
