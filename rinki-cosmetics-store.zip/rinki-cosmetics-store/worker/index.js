/* ===========================================================
   Rinki Cosmetics Store — backend (Cloudflare Worker)
   - Product catalogue in D1 (SQL), images in R2, secure admin login
   - Public JSON API for the storefront + protected admin API
   =========================================================== */
import { SAMPLE_PRODUCTS } from "./seed.js";
import ADMIN_HTML from "./admin.html";

const SESSION_COOKIE = "rinki_admin";
const SESSION_TTL = 7 * 24 * 60 * 60; // seconds
const MAX_LOGIN_FAILS = 10;
const LOGIN_WINDOW = 15 * 60 * 1000; // ms
const MAX_IMAGE_BYTES = 4 * 1024 * 1024;
const MAX_IMAGES = 6;
/* Cloudflare Workers caps PBKDF2 at 100,000 iterations */
const PBKDF2_ITERATIONS = 100000;

const CATEGORIES = ["makeup", "skincare", "haircare", "accessories", "fashion", "gifts", "cosmetics", "offers"];
const NEW_CATEGORIES = ["fashion", "gifts", "cosmetics"];
const OFFER_CATEGORY = "offers";
const DATA_VERSION = 4;
const TAGS = ["", "new", "trending", "bestseller"];

/* ---------- schema ---------- */
const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS products (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    price INTEGER NOT NULL,
    mrp INTEGER NOT NULL DEFAULT 0,
    rating REAL NOT NULL DEFAULT 4.5,
    reviews INTEGER NOT NULL DEFAULT 0,
    tag TEXT NOT NULL DEFAULT '',
    description TEXT NOT NULL DEFAULT '',
    details TEXT NOT NULL DEFAULT '[]',
    images TEXT NOT NULL DEFAULT '[]',
    stock INTEGER NOT NULL DEFAULT 0,
    available INTEGER NOT NULL DEFAULT 1,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    pass_hash TEXT NOT NULL,
    pass_salt TEXT NOT NULL,
    iterations INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    admin_id INTEGER NOT NULL,
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS login_attempts (
    key TEXT PRIMARY KEY,
    count INTEGER NOT NULL,
    window_start INTEGER NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL DEFAULT ''
  )`,
  `CREATE INDEX IF NOT EXISTS idx_products_available ON products (available, sort_order)`
];

/* ---------- tiny helpers ---------- */
const enc = new TextEncoder();

function toHex(bytes) {
  let out = "";
  for (const b of bytes) out += b.toString(16).padStart(2, "0");
  return out;
}
function fromHex(hex) {
  const out = new Uint8Array(hex.length / 2);
  for (let i = 0; i < out.length; i++) out[i] = parseInt(hex.substr(i * 2, 2), 16);
  return out;
}
function randomHex(bytes) {
  const buf = new Uint8Array(bytes);
  crypto.getRandomValues(buf);
  return toHex(buf);
}
function safeJson(text, fallback) {
  try {
    const parsed = JSON.parse(text);
    return parsed == null ? fallback : parsed;
  } catch (e) {
    return fallback;
  }
}
function timingSafeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
function json(data, status = 200, extra = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      ...extra
    }
  });
}
function fail(message, status = 400) {
  return json({ error: message }, status);
}

/* ---------- passwords ---------- */
async function hashPassword(password, saltHex, iterations) {
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: fromHex(saltHex), iterations: iterations, hash: "SHA-256" },
    key,
    256
  );
  return toHex(new Uint8Array(bits));
}
async function verifyPassword(password, admin) {
  const guess = await hashPassword(password, admin.pass_salt, admin.iterations || PBKDF2_ITERATIONS);
  return timingSafeEqual(guess, admin.pass_hash);
}

/* ---------- cookies & sessions ---------- */
function readCookies(request) {
  const raw = request.headers.get("Cookie") || "";
  const out = {};
  raw.split(";").forEach(part => {
    const i = part.indexOf("=");
    if (i > 0) {
      try {
        out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
      } catch (e) {
        /* ignore malformed cookie */
      }
    }
  });
  return out;
}
function sessionCookie(request, token, maxAge) {
  const secure = new URL(request.url).protocol === "https:" ? "; Secure" : "";
  return `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${secure}`;
}

async function createSession(request, env, adminId) {
  const token = randomHex(32);
  const tokenHash = toHex(new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(token))));
  const now = Date.now();
  await env.DB.prepare("DELETE FROM sessions WHERE expires_at < ?").bind(now).run();
  await env.DB
    .prepare("INSERT INTO sessions (token_hash, admin_id, created_at, expires_at) VALUES (?, ?, ?, ?)")
    .bind(tokenHash, adminId, now, now + SESSION_TTL * 1000)
    .run();
  return sessionCookie(request, token, SESSION_TTL);
}

async function currentAdmin(request, env) {
  const token = readCookies(request)[SESSION_COOKIE];
  if (!token) return null;
  const tokenHash = toHex(new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(token))));
  const row = await env.DB
    .prepare("SELECT a.id, a.username, s.expires_at FROM sessions s JOIN admins a ON a.id = s.admin_id WHERE s.token_hash = ?")
    .bind(tokenHash)
    .first();
  if (!row || row.expires_at < Date.now()) return null;
  return { id: row.id, username: row.username };
}

/* ---------- request guards ---------- */
function sameOrigin(request) {
  const origin = request.headers.get("Origin");
  if (!origin) return true;
  try {
    return new URL(origin).host === new URL(request.url).host;
  } catch (e) {
    return false;
  }
}
function clientIp(request) {
  return request.headers.get("CF-Connecting-IP") || request.headers.get("X-Forwarded-For") || "local";
}
async function loginBlocked(env, ip) {
  const row = await env.DB.prepare("SELECT count, window_start FROM login_attempts WHERE key = ?").bind(ip).first();
  if (!row) return false;
  if (Date.now() - row.window_start > LOGIN_WINDOW) {
    await env.DB.prepare("DELETE FROM login_attempts WHERE key = ?").bind(ip).run();
    return false;
  }
  return row.count >= MAX_LOGIN_FAILS;
}
async function noteLoginFail(env, ip) {
  const now = Date.now();
  const row = await env.DB.prepare("SELECT count, window_start FROM login_attempts WHERE key = ?").bind(ip).first();
  if (!row || now - row.window_start > LOGIN_WINDOW) {
    await env.DB
      .prepare("INSERT INTO login_attempts (key, count, window_start) VALUES (?, 1, ?) ON CONFLICT(key) DO UPDATE SET count = 1, window_start = ?")
      .bind(ip, now, now)
      .run();
    return;
  }
  await env.DB.prepare("UPDATE login_attempts SET count = count + 1 WHERE key = ?").bind(ip).run();
}
async function clearLoginFails(env, ip) {
  await env.DB.prepare("DELETE FROM login_attempts WHERE key = ?").bind(ip).run();
}

async function readJson(request, limit = 64 * 1024) {
  const text = await request.text();
  if (text.length > limit) throw new Error("too-large");
  if (!text) return {};
  try {
    return JSON.parse(text);
  } catch (e) {
    throw new Error("bad-json");
  }
}

/* ---------- product mapping / validation ---------- */
function rowToProduct(row) {
  return {
    id: row.id,
    name: row.name,
    category: row.category,
    price: row.price,
    mrp: row.mrp,
    rating: row.rating,
    reviews: row.reviews,
    tag: row.tag,
    description: row.description,
    desc: row.description,
    details: safeJson(row.details, []),
    images: safeJson(row.images, []),
    stock: row.stock,
    available: !!row.available,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

function cleanProduct(body) {
  const errors = [];
  const name = String(body.name == null ? "" : body.name).trim().slice(0, 120);
  if (name.length < 2) errors.push("Product name must be at least 2 characters");

  const category = CATEGORIES.indexOf(body.category) >= 0 ? body.category : "makeup";

  const price = Math.round(Number(body.price));
  if (!Number.isFinite(price) || price <= 0 || price > 1000000) errors.push("Enter a valid selling price");

  let mrp = Math.round(Number(body.mrp) || 0);
  if (!Number.isFinite(mrp) || mrp < 0) mrp = price;
  if (mrp < price) mrp = price;

  let rating = Number(body.rating);
  if (!Number.isFinite(rating)) rating = 4.5;
  rating = Math.min(5, Math.max(0, Math.round(rating * 10) / 10));

  let reviews = Math.round(Number(body.reviews) || 0);
  reviews = Math.max(0, Math.min(100000, reviews));

  const tag = TAGS.indexOf(body.tag) >= 0 ? body.tag : "";

  const description = String(body.description == null ? body.desc || "" : body.description).trim().slice(0, 2000);
  if (description.length < 3) errors.push("Please add a short description");

  const details = Array.isArray(body.details)
    ? body.details.map(d => String(d).trim().slice(0, 160)).filter(Boolean).slice(0, 12)
    : String(body.details || "")
        .split("\n")
        .map(d => d.trim().slice(0, 160))
        .filter(Boolean)
        .slice(0, 12);

  let images = Array.isArray(body.images) ? body.images : body.image ? [body.image] : [];
  const allowedImage = /^(\/media\/[A-Za-z0-9._/-]+|assets\/[A-Za-z0-9._/-]+|https:\/\/[A-Za-z0-9._~:/?#[\]@!$&'()*+,;=%-]+)$/;
  images = images
    .map(img => String(img).trim())
    .filter(img => img && allowedImage.test(img))
    .slice(0, MAX_IMAGES);

  let stock = Math.round(Number(body.stock) || 0);
  stock = Math.max(0, Math.min(100000, stock));

  const available = body.available === false || body.available === 0 || body.available === "0" ? 0 : 1;

  return {
    errors,
    product: {
      name,
      category,
      price,
      mrp,
      rating,
      reviews,
      tag,
      description,
      details,
      images,
      stock,
      available
    }
  };
}

async function uniqueId(env, name, ignoreId) {
  const base =
    name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 70) || "product";
  let candidate = base;
  let n = 2;
  for (;;) {
    const row = await env.DB.prepare("SELECT id FROM products WHERE id = ?").bind(candidate).first();
    if (!row || row.id === ignoreId) return candidate;
    candidate = base + "-" + n;
    n += 1;
  }
}

/* ---------- migrate + seed once ---------- */
let readyPromise = null;
function ensureReady(env) {
  if (!readyPromise) {
    readyPromise = migrate(env).catch(err => {
      readyPromise = null;
      throw err;
    });
  }
  return readyPromise;
}
async function migrate(env) {
  if (!env.DB) throw new Error("Database binding DB is missing");
  for (const statement of SCHEMA) {
    await env.DB.prepare(statement).run();
  }

  const now = new Date().toISOString();
  const count = await env.DB.prepare("SELECT COUNT(*) AS n FROM products").first();

  /* brand-new database: load the full starter catalogue */
  if (!count || count.n === 0) {
    await insertProducts(env, SAMPLE_PRODUCTS, now, SAMPLE_PRODUCTS.length);
    await setSetting(env, "data_version", String(DATA_VERSION));
    return;
  }

  /* existing shop: bring in the starter products for the newly added categories, once */
  const version = Number((await getSetting(env, "data_version")) || "1");
  if (version < 2) {
    const added = SAMPLE_PRODUCTS.filter(p => NEW_CATEGORIES.indexOf(p.category) >= 0);
    await insertProducts(env, added, now, 5000);
    await setSetting(env, "data_version", "2");
  }
  /* Offer Zone (₹99 Store) arrived in v3 */
  if (version < 3) {
    const offers = SAMPLE_PRODUCTS.filter(p => p.category === OFFER_CATEGORY);
    await insertProducts(env, offers, now, 6000);
    await setSetting(env, "data_version", "3");
  }
  /* v4: restore any starter products missing from the catalogue (never overwrites edits) */
  if (version < 4) {
    await insertProducts(env, SAMPLE_PRODUCTS, now, 6000);
    await setSetting(env, "data_version", "4");
  }
  if (version < DATA_VERSION) await setSetting(env, "data_version", String(DATA_VERSION));
}

async function insertProducts(env, list, now, baseSort) {
  const statements = list.map((p, index) =>
    env.DB
      .prepare(
        `INSERT OR IGNORE INTO products
         (id, name, category, price, mrp, rating, reviews, tag, description, details, images, stock, available, sort_order, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)`
      )
      .bind(
        p.id,
        p.name,
        p.category,
        p.price,
        p.mrp,
        p.rating,
        p.reviews,
        p.tag || "",
        p.desc,
        JSON.stringify(p.details || []),
        JSON.stringify(p.images && p.images.length ? p.images : [p.image]),
        Number.isFinite(p.stock) && p.stock > 0 ? p.stock : 12,
        baseSort - index,
        now,
        now
      )
  );
  if (statements.length) await env.DB.batch(statements);
}

async function getSetting(env, key) {
  const row = await env.DB.prepare("SELECT value FROM settings WHERE key = ?").bind(key).first();
  return row ? row.value : "";
}
async function setSetting(env, key, value) {
  await env.DB
    .prepare("INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value")
    .bind(key, value)
    .run();
}

/* ---------- image helpers ---------- */
function sniffImage(bytes) {
  const b = bytes;
  if (b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "jpg";
  if (b.length > 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return "png";
  if (b.length > 6 && b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x38) return "gif";
  if (
    b.length > 12 &&
    b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 &&
    b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50
  ) return "webp";
  return "";
}
const MIME = { jpg: "image/jpeg", png: "image/png", gif: "image/gif", webp: "image/webp" };

/* ---------- API ---------- */
async function handleApi(request, env, url) {
  const method = request.method.toUpperCase();
  const path = url.pathname;

  if (method !== "GET" && method !== "HEAD" && !sameOrigin(request)) {
    return fail("Cross-site request blocked", 403);
  }

  /* health */
  if (path === "/api/health" && method === "GET") {
    await ensureReady(env);
    const n = await env.DB.prepare("SELECT COUNT(*) AS n FROM products").first();
    return json({ ok: true, products: n ? n.n : 0 });
  }

  /* public catalogue */
  if (path === "/api/products" && method === "GET") {
    await ensureReady(env);
    const { results } = await env.DB
      .prepare("SELECT * FROM products WHERE available = 1 ORDER BY sort_order DESC, name ASC")
      .all();
    const products = (results || []).map(rowToProduct);
    return json({ products, count: products.length, updatedAt: new Date().toISOString() });
  }

  /* media */
  if (path.startsWith("/media/") && (method === "GET" || method === "HEAD")) {
    const key = decodeURIComponent(path.slice("/media/".length));
    if (!key || key.includes("..") || !env.FILES) return fail("Not found", 404);
    const object = await env.FILES.get(key);
    if (!object) return fail("Not found", 404);
    const headers = new Headers();
    object.writeHttpMetadata(headers);
    headers.set("etag", object.httpEtag);
    headers.set("cache-control", "public, max-age=31536000, immutable");
    headers.set("x-content-type-options", "nosniff");
    return new Response(method === "HEAD" ? null : object.body, { headers });
  }

  /* session state */
  if (path === "/api/auth/session" && method === "GET") {
    await ensureReady(env);
    const adminCount = await env.DB.prepare("SELECT COUNT(*) AS n FROM admins").first();
    const admin = await currentAdmin(request, env);
    return json({ authed: !!admin, username: admin ? admin.username : "", setupRequired: !adminCount || !adminCount.n });
  }

  /* first-run setup */
  if (path === "/api/auth/setup" && method === "POST") {
    await ensureReady(env);
    const ip = clientIp(request);
    if (await loginBlocked(env, ip)) return fail("Too many attempts. Please wait 15 minutes and try again.", 429);

    const adminCount = await env.DB.prepare("SELECT COUNT(*) AS n FROM admins").first();
    if (adminCount && adminCount.n > 0) return fail("An admin account already exists. Please sign in.", 409);

    let body;
    try {
      body = await readJson(request);
    } catch (e) {
      return fail("Invalid request", 400);
    }
    const username = String(body.username || "").trim().toLowerCase();
    const password = String(body.password || "");
    if (!/^[a-z0-9._-]{3,32}$/.test(username)) return fail("Username must be 3–32 characters: letters, numbers, dot, dash or underscore", 400);
    if (password.length < 8 || password.length > 200) return fail("Password must be at least 8 characters", 400);

    const salt = randomHex(16);
    const hash = await hashPassword(password, salt, PBKDF2_ITERATIONS);
    const now = new Date().toISOString();
    let info;
    try {
      info = await env.DB
        .prepare(
          "INSERT INTO admins (username, pass_hash, pass_salt, iterations, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)"
        )
        .bind(username, hash, salt, PBKDF2_ITERATIONS, now, now)
        .run();
    } catch (e) {
      return fail("An admin account already exists. Please sign in.", 409);
    }
    const adminId = info.meta && info.meta.last_row_id;
    const cookie = await createSession(request, env, adminId);
    await clearLoginFails(env, ip);
    return json({ ok: true, username, setupRequired: false }, 200, { "set-cookie": cookie });
  }

  /* login */
  if (path === "/api/auth/login" && method === "POST") {
    await ensureReady(env);
    const ip = clientIp(request);
    if (await loginBlocked(env, ip)) return fail("Too many failed attempts. Please wait 15 minutes and try again.", 429);

    let body;
    try {
      body = await readJson(request);
    } catch (e) {
      return fail("Invalid request", 400);
    }
    const username = String(body.username || "").trim().toLowerCase();
    const password = String(body.password || "");
    if (!username || !password) return fail("Enter your username and password", 400);

    const admin = await env.DB
      .prepare("SELECT * FROM admins WHERE username = ?")
      .bind(username)
      .first();
    if (!admin || !(await verifyPassword(password, admin))) {
      await noteLoginFail(env, ip);
      return fail("Incorrect username or password", 401);
    }
    await clearLoginFails(env, ip);
    const cookie = await createSession(request, env, admin.id);
    return json({ ok: true, username: admin.username }, 200, { "set-cookie": cookie });
  }

  /* logout */
  if (path === "/api/auth/logout" && method === "POST") {
    const token = readCookies(request)[SESSION_COOKIE];
    if (token) {
      const tokenHash = toHex(new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(token))));
      await env.DB.prepare("DELETE FROM sessions WHERE token_hash = ?").bind(tokenHash).run();
    }
    return json({ ok: true }, 200, { "set-cookie": sessionCookie(request, "", 0) });
  }

  /* change password */
  if (path === "/api/auth/password" && method === "POST") {
    await ensureReady(env);
    const admin = await currentAdmin(request, env);
    if (!admin) return fail("Please sign in again", 401);
    let body;
    try {
      body = await readJson(request);
    } catch (e) {
      return fail("Invalid request", 400);
    }
    const row = await env.DB.prepare("SELECT * FROM admins WHERE id = ?").bind(admin.id).first();
    if (!row || !(await verifyPassword(String(body.currentPassword || ""), row))) {
      return fail("Your current password is incorrect", 401);
    }
    const password = String(body.newPassword || "");
    if (password.length < 8 || password.length > 200) return fail("New password must be at least 8 characters", 400);
    const salt = randomHex(16);
    const hash = await hashPassword(password, salt, PBKDF2_ITERATIONS);
    await env.DB
      .prepare("UPDATE admins SET pass_hash = ?, pass_salt = ?, iterations = ?, updated_at = ? WHERE id = ?")
      .bind(hash, salt, PBKDF2_ITERATIONS, new Date().toISOString(), admin.id)
      .run();
    await env.DB.prepare("DELETE FROM sessions WHERE admin_id = ?").bind(admin.id).run();
    const cookie = await createSession(request, env, admin.id);
    return json({ ok: true }, 200, { "set-cookie": cookie });
  }

  /* everything below requires an admin session */
  const isAdminRoute = path.startsWith("/api/admin/");
  if (!isAdminRoute) return fail("Not found", 404);

  const admin = await currentAdmin(request, env);
  if (!admin) return fail("Please sign in", 401);

  /* dashboard stats */
  if (path === "/api/admin/stats" && method === "GET") {
    await ensureReady(env);
    const { results } = await env.DB.prepare("SELECT * FROM products").all();
    const products = (results || []).map(rowToProduct);
    return json({
      username: admin.username,
      stats: {
        total: products.length,
        visible: products.filter(p => p.available).length,
        hidden: products.filter(p => !p.available).length,
        outOfStock: products.filter(p => p.stock <= 0).length,
        lowStock: products.filter(p => p.stock > 0 && p.stock <= 5).length,
        units: products.reduce((n, p) => n + p.stock, 0),
        categories: CATEGORIES.reduce((acc, id) => {
          acc[id] = products.filter(p => p.category === id).length;
          return acc;
        }, {})
      }
    });
  }

  /* admin product list (includes hidden + out of stock) */
  if (path === "/api/admin/products" && method === "GET") {
    await ensureReady(env);
    const { results } = await env.DB.prepare("SELECT * FROM products ORDER BY sort_order DESC, name ASC").all();
    return json({ products: (results || []).map(rowToProduct) });
  }

  /* create */
  if (path === "/api/admin/products" && method === "POST") {
    await ensureReady(env);
    let body;
    try {
      body = await readJson(request);
    } catch (e) {
      return fail("Invalid product data", 400);
    }
    const { errors, product } = cleanProduct(body);
    if (errors.length) return json({ error: errors[0], errors }, 422);

    const now = new Date().toISOString();
    const id = await uniqueId(env, product.name);
    await env.DB
      .prepare(
        `INSERT INTO products
         (id, name, category, price, mrp, rating, reviews, tag, description, details, images, stock, available, sort_order, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .bind(
        id,
        product.name,
        product.category,
        product.price,
        product.mrp,
        product.rating,
        product.reviews,
        product.tag,
        product.description,
        JSON.stringify(product.details),
        JSON.stringify(product.images),
        product.stock,
        product.available,
        Date.now(),
        now,
        now
      )
      .run();
    const row = await env.DB.prepare("SELECT * FROM products WHERE id = ?").bind(id).first();
    return json({ ok: true, product: rowToProduct(row) }, 201);
  }

  /* update / delete a product */
  if (path.startsWith("/api/admin/products/")) {
    const id = decodeURIComponent(path.slice("/api/admin/products/".length));
    if (!id) return fail("Not found", 404);
    const existing = await env.DB.prepare("SELECT * FROM products WHERE id = ?").bind(id).first();
    if (!existing) return fail("Product not found", 404);

    if (method === "PUT" || method === "PATCH") {
      let body;
      try {
        body = await readJson(request);
      } catch (e) {
        return fail("Invalid product data", 400);
      }
      const merged = { ...rowToProduct(existing), ...body };
      const { errors, product } = cleanProduct(merged);
      if (errors.length) return json({ error: errors[0], errors }, 422);
      await env.DB
        .prepare(
          `UPDATE products SET name = ?, category = ?, price = ?, mrp = ?, rating = ?, reviews = ?, tag = ?,
           description = ?, details = ?, images = ?, stock = ?, available = ?, updated_at = ? WHERE id = ?`
        )
        .bind(
          product.name,
          product.category,
          product.price,
          product.mrp,
          product.rating,
          product.reviews,
          product.tag,
          product.description,
          JSON.stringify(product.details),
          JSON.stringify(product.images),
          product.stock,
          product.available,
          new Date().toISOString(),
          id
        )
        .run();
      const row = await env.DB.prepare("SELECT * FROM products WHERE id = ?").bind(id).first();
      return json({ ok: true, product: rowToProduct(row) });
    }

    if (method === "DELETE") {
      const images = safeJson(existing.images, []);
      await env.DB.prepare("DELETE FROM products WHERE id = ?").bind(id).run();
      if (env.FILES) {
        for (const image of images) {
          if (typeof image === "string" && image.startsWith("/media/")) {
            try {
              await env.FILES.delete(image.slice("/media/".length));
            } catch (e) {
              /* image cleanup is best effort */
            }
          }
        }
      }
      return json({ ok: true, id });
    }
    return fail("Method not allowed", 405);
  }

  /* image upload (multipart/form-data, field name: files) */
  if (path === "/api/admin/uploads" && method === "POST") {
    if (!env.FILES) return fail("Image storage is not configured", 500);
    let form;
    try {
      form = await request.formData();
    } catch (e) {
      return fail("Could not read the uploaded images", 400);
    }
    const files = [];
    for (const value of form.getAll("files")) {
      if (value && typeof value === "object" && typeof value.arrayBuffer === "function" && value.size > 0) files.push(value);
    }
    if (!files.length) return fail("No images received", 400);
    if (files.length > MAX_IMAGES) return fail(`You can upload up to ${MAX_IMAGES} images at once`, 400);

    const urls = [];
    for (const file of files) {
      if (file.size > MAX_IMAGE_BYTES) return fail("Each image must be under 4 MB", 413);
      const buffer = await file.arrayBuffer();
      const ext = sniffImage(new Uint8Array(buffer.slice(0, 16)));
      if (!ext) return fail("Only JPG, PNG, WEBP or GIF images are supported", 415);
      const key = `products/${Date.now().toString(36)}-${randomHex(6)}.${ext}`;
      await env.FILES.put(key, buffer, {
        httpMetadata: { contentType: MIME[ext], cacheControl: "public, max-age=31536000, immutable" }
      });
      urls.push(`/media/${key}`);
    }
    return json({ ok: true, urls }, 201);
  }

  return fail("Not found", 404);
}

/* ---------- security headers for HTML/assets ---------- */
function harden(response) {
  const headers = new Headers(response.headers);
  headers.set("x-content-type-options", "nosniff");
  headers.set("referrer-policy", "strict-origin-when-cross-origin");
  headers.set("permissions-policy", "camera=(), microphone=(), geolocation=()");
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;

    try {
      if (path.startsWith("/api/")) {
        return harden(await handleApi(request, env, url));
      }

      if (path.startsWith("/media/")) {
        return harden(await handleApi(request, env, url));
      }

      /* admin dashboard is served straight from the Worker at /admin */
      if (path === "/admin" || path === "/admin/" || path === "/admin/login") {
        return harden(
          new Response(ADMIN_HTML, {
            headers: {
              "content-type": "text/html; charset=utf-8",
              "cache-control": "no-store",
              "x-robots-tag": "noindex, nofollow"
            }
          })
        );
      }

      return harden(await env.ASSETS.fetch(request));
    } catch (err) {
      const message = err && err.message ? err.message : "Unexpected error";
      if (path.startsWith("/api/")) return json({ error: message }, 500);
      return new Response("Something went wrong. Please refresh the page.", {
        status: 500,
        headers: { "content-type": "text/plain; charset=utf-8" }
      });
    }
  }
};
