/* Regenerates worker/seed.js from the storefront's sample catalogue.
   Run with: npm run seed */
import fs from "node:fs";

const candidates = ["public/assets/js/data.js", "assets/js/data.js"];
const file = candidates.find(p => fs.existsSync(p));
if (!file) {
  console.error("Could not find data.js");
  process.exit(1);
}

const src = fs.readFileSync(file, "utf8");
const start = src.indexOf("const SAMPLE_PRODUCTS =");
const open = src.indexOf("[", start);
let depth = 0;
let end = -1;
for (let i = open; i < src.length; i++) {
  if (src[i] === "[") depth++;
  else if (src[i] === "]") {
    depth--;
    if (depth === 0) {
      end = i + 1;
      break;
    }
  }
}
if (start < 0 || open < 0 || end < 0) {
  console.error("Could not locate SAMPLE_PRODUCTS in " + file);
  process.exit(1);
}

const literal = src.slice(open, end);
const products = new Function("return (" + literal + ");")();

const seeded = products.map(p => ({
  id: p.id,
  name: p.name,
  category: p.category,
  price: p.price,
  mrp: p.mrp,
  rating: p.rating,
  reviews: p.reviews,
  tag: p.tag || "",
  desc: p.desc,
  details: p.details || [],
  image: p.image,
  images: [p.image],
  stock: 12
}));

fs.mkdirSync("worker", { recursive: true });
fs.writeFileSync(
  "worker/seed.js",
  "/* Generated from " + file + " by tools/build-seed.mjs — do not edit by hand */\n" +
    "export const SAMPLE_PRODUCTS = " + JSON.stringify(seeded, null, 2) + ";\n"
);
console.log("Wrote worker/seed.js with " + seeded.length + " sample products");
