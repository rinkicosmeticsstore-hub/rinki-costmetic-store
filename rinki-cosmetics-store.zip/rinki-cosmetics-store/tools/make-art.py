#!/usr/bin/env python3
"""Generate SVG product illustrations + hero art for Rinki Cosmetics Store."""
import os

OUT = "assets/products"
HERO = "assets/hero"
os.makedirs(OUT, exist_ok=True)
os.makedirs(HERO, exist_ok=True)

W = H = 600


def head(c1, c2, light1, light2):
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 600" width="600" height="600" role="img">
<defs>
  <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="{light1}"/><stop offset="1" stop-color="{light2}"/>
  </linearGradient>
  <linearGradient id="body" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#fdf4fa"/>
  </linearGradient>
  <linearGradient id="accent" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="{c1}"/><stop offset="1" stop-color="{c2}"/>
  </linearGradient>
</defs>
<rect width="600" height="600" fill="url(#bg)"/>
<circle cx="470" cy="130" r="150" fill="#ffffff" opacity=".28"/>
<circle cx="120" cy="500" r="120" fill="#ffffff" opacity=".22"/>
<circle cx="500" cy="480" r="70" fill="{c1}" opacity=".12"/>
<ellipse cx="300" cy="500" rx="150" ry="26" fill="{c2}" opacity=".16"/>
'''


def sparkle(x, y, s, color):
    return f'<path d="M{x} {y-s} L{x+s*0.28} {y-s*0.28} L{x+s} {y} L{x+s*0.28} {y+s*0.28} L{x} {y+s} L{x-s*0.28} {y+s*0.28} L{x-s} {y} L{x-s*0.28} {y-s*0.28} Z" fill="{color}" opacity=".85"/>'


def body_lipstick(c1, c2):
    return f'''
<path d="M258 300 L258 246 Q258 232 272 229 L322 236 L348 300 Z" fill="url(#accent)"/>
<rect x="250" y="292" width="104" height="26" fill="{c1}" opacity=".85"/>
<rect x="244" y="314" width="116" height="176" rx="16" fill="url(#body)" stroke="{c1}" stroke-opacity=".35"/>
<rect x="244" y="404" width="116" height="42" fill="url(#accent)" opacity=".9"/>
<rect x="260" y="330" width="16" height="140" rx="8" fill="#ffffff" opacity=".75"/>
<text x="302" y="432" font-family="Georgia,serif" font-size="20" fill="#fff" text-anchor="middle" letter-spacing="2">RINKI</text>
''' + sparkle(410, 250, 22, c1) + sparkle(196, 300, 14, c2)


def body_bottle(c1, c2):
    return f'''
<rect x="272" y="176" width="56" height="44" rx="10" fill="{c2}"/>
<rect x="286" y="216" width="28" height="30" fill="{c1}" opacity=".8"/>
<path d="M232 268 Q232 240 262 240 H338 Q368 240 368 268 V462 Q368 492 338 492 H262 Q232 492 232 462 Z" fill="url(#body)" stroke="{c1}" stroke-opacity=".4"/>
<path d="M240 320 H360 V450 Q360 480 330 480 H270 Q240 480 240 450 Z" fill="{c1}" opacity=".55"/>
<rect x="252" y="330" width="96" height="96" rx="14" fill="#ffffff" opacity=".8"/>
<text x="300" y="372" font-family="Georgia,serif" font-size="19" fill="{c2}" text-anchor="middle">RINKI</text>
<text x="300" y="396" font-family="Helvetica,Arial" font-size="11" fill="{c2}" text-anchor="middle" letter-spacing="2">GLOW</text>
<rect x="248" y="272" width="16" height="200" rx="8" fill="#ffffff" opacity=".6"/>
''' + sparkle(398, 300, 20, c1)


def body_pencil(c1, c2):
    return f'''
<g transform="rotate(-18 300 300)">
  <rect x="286" y="150" width="30" height="52" rx="8" fill="{c2}"/>
  <rect x="286" y="196" width="30" height="210" rx="6" fill="url(#accent)"/>
  <rect x="286" y="196" width="30" height="210" rx="6" fill="#ffffff" opacity=".18"/>
  <path d="M286 402 H316 L301 452 Z" fill="#3a2440"/>
  <rect x="292" y="204" width="8" height="180" rx="4" fill="#ffffff" opacity=".35"/>
</g>
''' + sparkle(420, 220, 20, c1) + sparkle(170, 380, 14, c2)


def body_compact(c1, c2):
    return f'''
<circle cx="300" cy="316" r="128" fill="url(#body)" stroke="{c1}" stroke-opacity=".35"/>
<circle cx="300" cy="316" r="104" fill="{c1}" opacity=".28"/>
<circle cx="300" cy="316" r="76" fill="url(#accent)" opacity=".9"/>
<path d="M232 254 A128 128 0 0 1 368 254 Z" fill="#ffffff" opacity=".55"/>
<circle cx="300" cy="316" r="128" fill="none" stroke="{c2}" stroke-width="3" opacity=".35"/>
''' + sparkle(420, 200, 22, c1)


def body_palette(c1, c2):
    shades = ["#f8c8dc", "#e890b4", "#c9608f", "#8e4a70",
              "#d9c2f0", "#b98fe0", "#8c5bc0", "#5f3a86",
              "#f3d2b8", "#d9a882", "#b3835c", "#7a5540"]
    cells = []
    for i, col in enumerate(shades):
        r, c = divmod(i, 4)
        cells.append(f'<rect x="{196 + c*54}" y="{258 + r*44}" width="42" height="32" rx="7" fill="{col}"/>')
    return f'''
<rect x="164" y="222" width="272" height="228" rx="26" fill="url(#body)" stroke="{c1}" stroke-opacity=".35"/>
<rect x="180" y="238" width="240" height="196" rx="18" fill="#ffffff"/>
{''.join(cells)}
<rect x="164" y="222" width="272" height="30" rx="15" fill="url(#accent)" opacity=".85"/>
''' + sparkle(452, 210, 20, c1)


def body_mascara(c1, c2):
    return f'''
<rect x="266" y="238" width="68" height="236" rx="14" fill="url(#body)" stroke="{c1}" stroke-opacity=".4"/>
<rect x="276" y="300" width="48" height="120" rx="8" fill="url(#accent)" opacity=".9"/>
<text x="300" y="366" font-family="Georgia,serif" font-size="22" fill="#fff" text-anchor="middle">R</text>
<rect x="258" y="150" width="84" height="92" rx="14" fill="{c2}"/>
<rect x="270" y="158" width="14" height="76" rx="7" fill="#ffffff" opacity=".3"/>
<rect x="272" y="252" width="14" height="200" rx="7" fill="#ffffff" opacity=".55"/>
''' + sparkle(404, 260, 18, c1)


def body_nailpolish(c1, c2):
    return f'''
<rect x="254" y="322" width="92" height="140" rx="20" fill="url(#body)" stroke="{c1}" stroke-opacity=".4"/>
<rect x="262" y="360" width="76" height="96" rx="14" fill="url(#accent)"/>
<rect x="280" y="286" width="40" height="42" fill="{c1}" opacity=".7"/>
<rect x="266" y="164" width="68" height="126" rx="14" fill="{c2}"/>
<rect x="278" y="176" width="12" height="100" rx="6" fill="#ffffff" opacity=".28"/>
''' + sparkle(400, 300, 20, c1)


def body_serum(c1, c2):
    return f'''
<ellipse cx="300" cy="176" rx="26" ry="20" fill="{c2}"/>
<rect x="274" y="188" width="52" height="26" rx="6" fill="{c2}" opacity=".85"/>
<rect x="278" y="212" width="44" height="34" fill="{c1}" opacity=".7"/>
<path d="M240 264 Q240 246 264 246 H336 Q360 246 360 264 V462 Q360 490 332 490 H268 Q240 490 240 462 Z" fill="url(#body)" stroke="{c1}" stroke-opacity=".4"/>
<path d="M248 340 H352 V450 Q352 480 324 480 H276 Q248 480 248 450 Z" fill="url(#accent)" opacity=".75"/>
<rect x="256" y="326" width="88" height="72" rx="12" fill="#ffffff" opacity=".85"/>
<text x="300" y="356" font-family="Georgia,serif" font-size="17" fill="{c2}" text-anchor="middle">RINKI</text>
<text x="300" y="378" font-family="Helvetica,Arial" font-size="10" fill="{c2}" text-anchor="middle" letter-spacing="2">SERUM</text>
<rect x="252" y="270" width="12" height="200" rx="6" fill="#ffffff" opacity=".6"/>
''' + sparkle(400, 250, 22, c1)


def body_tube(c1, c2):
    return f'''
<rect x="270" y="188" width="60" height="62" rx="12" fill="{c2}"/>
<path d="M248 250 H352 L366 470 Q368 492 346 492 H254 Q232 492 234 470 Z" fill="url(#body)" stroke="{c1}" stroke-opacity=".4"/>
<path d="M244 300 H356 L364 452 Q366 476 342 476 H258 Q234 476 236 452 Z" fill="url(#accent)" opacity=".82"/>
<circle cx="300" cy="380" r="42" fill="#ffffff" opacity=".9"/>
<text x="300" y="376" font-family="Georgia,serif" font-size="20" fill="{c2}" text-anchor="middle">R</text>
<text x="300" y="396" font-family="Helvetica,Arial" font-size="9" fill="{c2}" text-anchor="middle" letter-spacing="1">CARE</text>
''' + sparkle(406, 270, 18, c1)


def body_jar(c1, c2):
    return f'''
<rect x="206" y="300" width="188" height="176" rx="30" fill="url(#body)" stroke="{c1}" stroke-opacity=".4"/>
<rect x="220" y="344" width="160" height="116" rx="22" fill="url(#accent)" opacity=".65"/>
<rect x="198" y="248" width="204" height="60" rx="20" fill="{c2}"/>
<rect x="214" y="258" width="60" height="12" rx="6" fill="#ffffff" opacity=".35"/>
<circle cx="300" cy="400" r="34" fill="#ffffff" opacity=".9"/>
<text x="300" y="408" font-family="Georgia,serif" font-size="22" fill="{c2}" text-anchor="middle">R</text>
''' + sparkle(424, 300, 20, c1)


def body_sachet(c1, c2):
    return f'''
<path d="M206 250 H394 V470 Q394 490 374 490 H226 Q206 490 206 470 Z" fill="url(#body)" stroke="{c1}" stroke-opacity=".35"/>
<path d="M206 250 H394 V310 H206 Z" fill="url(#accent)"/>
<path d="M206 250 H394" stroke="{c2}" stroke-width="8"/>
<circle cx="300" cy="392" r="52" fill="{c1}" opacity=".18"/>
<text x="300" y="386" font-family="Georgia,serif" font-size="22" fill="{c2}" text-anchor="middle">RINKI</text>
<text x="300" y="410" font-family="Helvetica,Arial" font-size="11" fill="{c2}" text-anchor="middle" letter-spacing="2">UBTAN</text>
''' + sparkle(430, 230, 18, c1)


def body_mirror(c1, c2):
    lights = "".join(
        f'<circle cx="{300 + 118 * __import__("math").cos(a)}" cy="{286 + 118 * __import__("math").sin(a)}" r="8" fill="#fff8d8"/>'
        for a in [i * 0.5236 for i in range(12)])
    return f'''
<circle cx="300" cy="286" r="138" fill="url(#body)" stroke="{c1}" stroke-opacity=".4" stroke-width="6"/>
<circle cx="300" cy="286" r="116" fill="{c1}" opacity=".14"/>
{lights}
<rect x="288" y="424" width="24" height="44" fill="{c2}"/>
<rect x="234" y="462" width="132" height="20" rx="10" fill="{c2}"/>
<path d="M232 240 A116 116 0 0 1 340 196" stroke="#ffffff" stroke-width="14" fill="none" opacity=".7" stroke-linecap="round"/>
''' + sparkle(452, 200, 20, c1)


def body_brush(c1, c2):
    return f'''
<g transform="rotate(-14 300 300)">
  <path d="M272 200 Q300 168 328 200 L328 268 H272 Z" fill="url(#accent)"/>
  <rect x="270" y="266" width="60" height="40" rx="8" fill="#e6d9ee" stroke="{c2}" stroke-opacity=".3"/>
  <rect x="284" y="304" width="32" height="180" rx="16" fill="{c2}"/>
  <rect x="292" y="316" width="8" height="150" rx="4" fill="#ffffff" opacity=".35"/>
</g>
<g transform="rotate(16 400 330)">
  <path d="M382 250 Q404 226 426 250 L426 300 H382 Z" fill="url(#accent)" opacity=".8"/>
  <rect x="380" y="298" width="48" height="32" rx="7" fill="#e6d9ee"/>
  <rect x="392" y="328" width="26" height="140" rx="13" fill="{c2}" opacity=".85"/>
</g>
''' + sparkle(200, 240, 18, c1)


def body_pouch(c1, c2):
    return f'''
<path d="M196 268 Q196 244 224 244 H376 Q404 244 404 268 V452 Q404 486 368 486 H232 Q196 486 196 452 Z" fill="url(#accent)"/>
<path d="M196 300 H404 V322 H196 Z" fill="#ffffff" opacity=".65"/>
<path d="M196 300 H404" stroke="{c2}" stroke-width="4" stroke-dasharray="10 8"/>
<circle cx="300" cy="400" r="44" fill="#ffffff" opacity=".9"/>
<text x="300" y="408" font-family="Georgia,serif" font-size="24" fill="{c2}" text-anchor="middle">R</text>
<path d="M260 244 Q260 206 300 206 Q340 206 340 244" stroke="{c2}" stroke-width="12" fill="none" opacity=".8"/>
''' + sparkle(440, 230, 18, c1)


def body_misc(c1, c2):
    return f'''
<circle cx="258" cy="330" r="74" fill="url(#accent)" opacity=".9"/>
<circle cx="352" cy="366" r="54" fill="#ffffff" opacity=".9"/>
<circle cx="316" cy="252" r="36" fill="{c1}" opacity=".55"/>
<path d="M258 256 L272 302 L318 316 L272 330 L258 376 L244 330 L198 316 L244 302 Z" fill="#ffffff" opacity=".85"/>
''' + sparkle(414, 246, 22, c1) + sparkle(186, 430, 16, c2)


SHAPES = {
    "lipstick": body_lipstick, "bottle": body_bottle, "pencil": body_pencil,
    "compact": body_compact, "palette": body_palette, "mascara": body_mascara,
    "nailpolish": body_nailpolish, "serum": body_serum, "tube": body_tube,
    "jar": body_jar, "sachet": body_sachet, "mirror": body_mirror,
    "brush": body_brush, "pouch": body_pouch, "misc": body_misc,
}

# id, shape, accent colors, background light colors
PRODUCTS = [
    ("velvet-matte-lipstick", "lipstick", "#d6336c", "#8b2f6b", "#ffe9f3", "#f6e2ff"),
    ("glow-foundation", "bottle", "#c9548f", "#7d3ba8", "#ffeaf4", "#efe4ff"),
    ("intense-kajal", "pencil", "#3c2a4d", "#7a4d94", "#f7e9f6", "#eeebfd"),
    ("oil-control-compact", "compact", "#e291b5", "#a15aa0", "#fff0f7", "#f3e8fc"),
    ("rose-eyeshadow-palette", "palette", "#e35d94", "#8a44b8", "#ffe9f3", "#f0e6ff"),
    ("volume-mascara", "mascara", "#4a2f60", "#8d55b8", "#f9ecf7", "#ece6ff"),
    ("cheek-blush", "compact", "#f08fb4", "#c95f9d", "#fff1f6", "#f6e8ff"),
    ("gel-nail-polish", "nailpolish", "#d63f86", "#8b3bd0", "#ffeaf5", "#f1e7ff"),
    ("vitamin-c-serum", "serum", "#f0a13c", "#d9634f", "#fff4e9", "#f7ecff"),
    ("hydra-face-wash", "tube", "#3fb6a8", "#3c8bc4", "#e9fbf7", "#eeeafd"),
    ("aloe-gel-moisturizer", "jar", "#4cc38c", "#2f9e8f", "#eafaf0", "#f0ebfd"),
    ("sunscreen-spf50", "tube", "#f2b23c", "#e07a5f", "#fff6e6", "#f5ecff"),
    ("ubtan-face-pack", "sachet", "#e0a24a", "#b7743c", "#fff5e7", "#f6eaf9"),
    ("rose-water-toner", "bottle", "#e77fae", "#a960c9", "#ffeef6", "#f2e9ff"),
    ("under-eye-gel", "tube", "#6f8fe0", "#8a5cc4", "#eef2ff", "#f2e8ff"),
    ("onion-hair-oil", "bottle", "#c9843f", "#8d5a95", "#fff2e5", "#f3e9fc"),
    ("keratin-shampoo", "bottle", "#d0639c", "#7b4bb8", "#ffeaf6", "#f0e8ff"),
    ("silk-conditioner", "bottle", "#cf7fb0", "#9b5fc4", "#fff0f8", "#f4eaff"),
    ("hair-serum", "serum", "#b97fe0", "#6f47b0", "#f8ecff", "#f0e6ff"),
    ("hair-spa-mask", "jar", "#d98fb8", "#8f4fa8", "#fff1f7", "#f2e9fd"),
    ("makeup-brush-set", "brush", "#d95f9c", "#7c3fb4", "#ffeaf5", "#efe5ff"),
    ("beauty-blender", "misc", "#f08fb4", "#a45cd0", "#fff0f7", "#f1e8ff"),
    ("eyelash-curler", "misc", "#b8a3c9", "#7e57a0", "#f7f0fb", "#eee8fc"),
    ("vanity-mirror", "mirror", "#e08fc0", "#8c5bc0", "#fff1f9", "#f0e9ff"),
    ("scrunchies-set", "misc", "#eaa0c4", "#b06cd0", "#fff2f8", "#f4eaff"),
    ("manicure-kit", "pouch", "#cf6e9e", "#74439c", "#fdeef6", "#efe7fd"),
    ("makeup-pouch", "pouch", "#d4568f", "#8d45b4", "#ffe9f3", "#f0e6ff"),
    ("jade-roller", "misc", "#6fc0a8", "#6a72c9", "#ecfaf3", "#eeebfd"),
]

for pid, shape, c1, c2, l1, l2 in PRODUCTS:
    svg = head(c1, c2, l1, l2) + SHAPES[shape](c1, c2) + "\n</svg>\n"
    with open(os.path.join(OUT, pid + ".svg"), "w") as f:
        f.write(svg)

# ---------------- hero art ----------------
def hero(accent1, accent2, l1, l2, main_shape, second_shape, title):
    body = head(accent1, accent2, l1, l2)
    body += '<ellipse cx="300" cy="505" rx="210" ry="30" fill="%s" opacity=".18"/>' % accent2
    body += '<g transform="translate(70 60) scale(0.62)">' + SHAPES[main_shape]("#d6336c", "#7b3fa8") + "</g>"
    body += '<g transform="translate(232 150) scale(0.52)">' + SHAPES[second_shape]("#cf5aa1", "#8a48c0") + "</g>"
    body += sparkle(470, 140, 30, accent1) + sparkle(120, 200, 20, accent2) + sparkle(500, 380, 18, accent1)
    body += '<circle cx="480" cy="470" r="42" fill="#ffffff" opacity=".45"/>'
    body += "</svg>\n"
    return body

HEROES = [
    ("hero-1.svg", "#d6336c", "#7b3fa8", "#ffeaf4", "#ece2ff", "lipstick", "compact"),
    ("hero-2.svg", "#3fb6a8", "#8a48c0", "#eafaf7", "#eee6ff", "serum", "jar"),
    ("hero-3.svg", "#c9843f", "#8d5a95", "#fff2e6", "#f0e8ff", "bottle", "jar"),
]
for name, a1, a2, l1, l2, s1, s2 in HEROES:
    with open(os.path.join(HERO, name), "w") as f:
        f.write(hero(a1, a2, l1, l2, s1, s2, name))

print("generated", len(PRODUCTS), "product images and", len(HEROES), "hero images")


# ===========================================================
# Fashion, Gift Items and Cosmetics (added categories)
# ===========================================================
def body_dress(c1, c2):
    return f'''
<path d="M300 148 L246 176 L212 300 L246 318 L258 472 Q300 488 342 472 L354 318 L388 300 L354 176 Z" fill="url(#accent)" opacity=".94"/>
<path d="M300 148 L246 176 L264 256 L300 270 L336 256 L354 176 Z" fill="#ffffff" opacity=".5"/>
<path d="M212 300 L246 318 M388 300 L354 318" stroke="#ffffff" stroke-width="6" opacity=".45"/>
<path d="M258 472 Q300 488 342 472" stroke="{c2}" stroke-width="10" fill="none" opacity=".45"/>
<circle cx="300" cy="216" r="8" fill="#ffffff" opacity=".85"/>
<circle cx="300" cy="248" r="6" fill="#ffffff" opacity=".75"/>
<path d="M236 340 Q300 372 364 340" stroke="#ffffff" stroke-width="3" fill="none" opacity=".4"/>
''' + sparkle(414, 206, 22, c1) + sparkle(188, 336, 15, c2)


def body_scarf(c1, c2):
    return f'''
<path d="M180 238 Q300 186 420 238 L438 420 Q300 472 162 420 Z" fill="url(#accent)" opacity=".92"/>
<path d="M180 238 Q300 292 420 238" stroke="#ffffff" stroke-width="9" fill="none" opacity=".55"/>
<path d="M172 300 Q300 352 428 300" stroke="#ffffff" stroke-width="3" fill="none" opacity=".38"/>
<path d="M166 362 Q300 414 434 362" stroke="#ffffff" stroke-width="3" fill="none" opacity=".28"/>
<path d="M162 420 Q300 472 438 420" stroke="{c2}" stroke-width="7" fill="none" opacity=".5"/>
''' + sparkle(444, 196, 20, c1) + sparkle(180, 480, 14, c2)


def body_giftbox(c1, c2):
    return f'''
<rect x="198" y="300" width="204" height="176" rx="14" fill="url(#accent)"/>
<rect x="180" y="248" width="240" height="64" rx="14" fill="{c2}"/>
<rect x="286" y="248" width="28" height="228" fill="#ffffff" opacity=".72"/>
<path d="M300 248 Q246 196 222 212 Q204 228 244 248 Z" fill="#ffffff" opacity=".88"/>
<path d="M300 248 Q354 196 378 212 Q396 228 356 248 Z" fill="#ffffff" opacity=".88"/>
<circle cx="300" cy="248" r="12" fill="#ffffff"/>
''' + sparkle(432, 236, 20, c1) + sparkle(178, 348, 15, c2)


def body_jewellery(c1, c2):
    return f'''
<path d="M208 208 Q300 404 392 208" stroke="url(#accent)" stroke-width="12" fill="none" stroke-linecap="round"/>
<circle cx="300" cy="386" r="32" fill="url(#accent)"/>
<circle cx="300" cy="386" r="15" fill="#ffffff" opacity=".85"/>
<circle cx="224" cy="282" r="5" fill="{c1}"/>
<circle cx="376" cy="282" r="5" fill="{c1}"/>
<circle cx="300" cy="333" r="7" fill="{c2}"/>
<path d="M262 208 Q300 240 338 208" stroke="#ffffff" stroke-width="4" fill="none" opacity=".5"/>
''' + sparkle(414, 252, 21, c1) + sparkle(190, 420, 15, c2)


def body_candle(c1, c2):
    return f'''
<rect x="236" y="286" width="128" height="200" rx="18" fill="url(#body)" stroke="{c1}" stroke-opacity=".4"/>
<rect x="248" y="332" width="104" height="138" rx="14" fill="url(#accent)" opacity=".85"/>
<ellipse cx="300" cy="286" rx="64" ry="14" fill="{c2}" opacity=".5"/>
<rect x="294" y="256" width="12" height="32" rx="4" fill="{c2}"/>
<path d="M300 196 Q320 232 300 262 Q280 232 300 196 Z" fill="#ffcf6b"/>
<text x="300" y="418" font-family="Georgia,serif" font-size="22" fill="#ffffff" text-anchor="middle">R</text>
''' + sparkle(404, 300, 19, c1)


SHAPES.update({
    "dress": body_dress,
    "scarf": body_scarf,
    "giftbox": body_giftbox,
    "jewellery": body_jewellery,
    "candle": body_candle,
})

NEW_PRODUCTS = [
    ("fashion-cotton-kurti", "dress", "#c2568a", "#7b3fa8", "#ffe9f2", "#f2e7ff"),
    ("fashion-floral-saree", "scarf", "#d4518f", "#8b3fc0", "#ffeaf5", "#f0e6ff"),
    ("fashion-handloom-dupatta", "scarf", "#b8763f", "#8a5a9c", "#fff1e6", "#f3e9fc"),
    ("gifts-beauty-hamper", "giftbox", "#d1789f", "#8f4dbb", "#fff0f7", "#efe6ff"),
    ("gifts-jewellery-box", "jewellery", "#c9a227", "#a05bb8", "#fff8e5", "#f4e9ff"),
    ("gifts-candle-set", "candle", "#e0917f", "#9a5bb5", "#fff2ec", "#f3e9ff"),
    ("cosmetics-daily-kit", "palette", "#e0559b", "#7e3fc0", "#ffe9f4", "#f0e6ff"),
    ("cosmetics-bridal-kit", "pouch", "#cf3a72", "#6f2fa8", "#ffe7f0", "#efe3ff"),
    ("cosmetics-perfume-mist", "bottle", "#e080b4", "#8b56d0", "#fff0f8", "#f2e8ff"),
]

for pid, shape, c1, c2, l1, l2 in NEW_PRODUCTS:
    svg = head(c1, c2, l1, l2) + SHAPES[shape](c1, c2) + "\n</svg>\n"
    with open(os.path.join(OUT, pid + ".svg"), "w") as f:
        f.write(svg)


# ---------------- category tiles ----------------
CAT_OUT = "assets/categories"
os.makedirs(CAT_OUT, exist_ok=True)


def category_tile(c1, c2, l1, l2, shape):
    motif = SHAPES[shape](c1, c2)
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 420" width="600" height="420" role="img">
<defs>
  <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="{l1}"/><stop offset="1" stop-color="{l2}"/>
  </linearGradient>
  <linearGradient id="body" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#fdf4fa"/>
  </linearGradient>
  <linearGradient id="accent" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="{c1}"/><stop offset="1" stop-color="{c2}"/>
  </linearGradient>
</defs>
<rect width="600" height="420" fill="url(#bg)"/>
<circle cx="512" cy="82" r="120" fill="#ffffff" opacity=".3"/>
<circle cx="86" cy="356" r="104" fill="#ffffff" opacity=".24"/>
<circle cx="470" cy="360" r="56" fill="{c1}" opacity=".14"/>
<g transform="translate(300 206) scale(0.62) translate(-300 -330)">{motif}</g>
<path d="M96 96 L108 120 L132 132 L108 144 L96 168 L84 144 L60 132 L84 120 Z" fill="#ffffff" opacity=".5"/>
<path d="M512 300 L520 316 L536 324 L520 332 L512 348 L504 332 L488 324 L504 316 Z" fill="#ffffff" opacity=".45"/>
</svg>
'''

CATEGORY_TILES = [
    ("makeup", "lipstick", "#e0559b", "#8a44b8", "#ffe9f3", "#f0e6ff"),
    ("skincare", "serum", "#3fb6a8", "#8a48c0", "#eafaf7", "#eee6ff"),
    ("haircare", "bottle", "#c9843f", "#8d5a95", "#fff2e6", "#f0e8ff"),
    ("accessories", "brush", "#d95f9c", "#7c3fb4", "#ffeaf5", "#efe5ff"),
    ("fashion", "dress", "#d4518f", "#7b3fa8", "#ffeaf3", "#f3e6ff"),
    ("gifts", "giftbox", "#d1a02a", "#a05bb8", "#fff7e3", "#f6e8ff"),
    ("cosmetics", "mirror", "#e0459a", "#6f2fb0", "#ffe7f2", "#efe3ff"),
]

for cid, shape, c1, c2, l1, l2 in CATEGORY_TILES:
    with open(os.path.join(CAT_OUT, cid + ".svg"), "w") as f:
        f.write(category_tile(c1, c2, l1, l2, shape))

# ===========================================================
# Offer Zone (₹99 Store)
# ===========================================================
def body_tag(c1, c2):
    return f'''
<path d="M212 300 L300 212 L388 300 L300 388 Z" fill="url(#accent)" opacity=".95"/>
<circle cx="300" cy="300" r="84" fill="#ffffff" opacity=".93"/>
<text x="300" y="292" font-family="Helvetica,Arial,sans-serif" font-size="24" font-weight="bold" fill="{c2}" text-anchor="middle" letter-spacing="2">ONLY</text>
<text x="300" y="352" font-family="Georgia,serif" font-size="68" font-weight="bold" fill="{c1}" text-anchor="middle">99</text>
<path d="M300 212 L300 172" stroke="{c1}" stroke-width="6" stroke-linecap="round"/>
''' + sparkle(432, 244, 20, c1) + sparkle(176, 352, 15, c2)


SHAPES["tag"] = body_tag

OFFER_PRODUCTS = [
    ("offer-kajal-99", "pencil", "#c33b74", "#7b3fa8", "#ffe8f1", "#f1e6ff"),
    ("offer-nail-polish-99", "nailpolish", "#e0559b", "#8b3fc0", "#ffe9f4", "#f0e6ff"),
    ("offer-lip-balm-99", "tube", "#d4518f", "#7e3fbb", "#ffeaf5", "#f0e6ff"),
]

for pid, shape, c1, c2, l1, l2 in OFFER_PRODUCTS:
    svg = head(c1, c2, l1, l2) + SHAPES[shape](c1, c2) + "\n</svg>\n"
    with open(os.path.join(OUT, pid + ".svg"), "w") as f:
        f.write(svg)

with open(os.path.join(CAT_OUT, "offers.svg"), "w") as f:
    f.write(category_tile("#e0459a", "#6f2fb0", "#ffe7f2", "#efe3ff", "tag"))

print("added", len(NEW_PRODUCTS), "products and", len(CATEGORY_TILES), "category images")
print("added", len(OFFER_PRODUCTS), "offer products and 1 offer category image")
